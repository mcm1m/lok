﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppInterface
{
    class Test : Program, ITriangle , ISquare
    {
         void ITriangle.Area()
        {

        }
        public void M1()
        {
            
        }
        public string Zx{get; set;}
        public void M2()
        {
            
        }

        void ISquare.Area()
        {
           
        }
        public void MM()
        {

        }
    }
}
