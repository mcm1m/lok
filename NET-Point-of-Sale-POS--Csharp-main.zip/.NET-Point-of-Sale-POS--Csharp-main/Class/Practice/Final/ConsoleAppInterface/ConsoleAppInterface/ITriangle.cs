﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppInterface
{
    interface ITriangle
    {
        void Area();
        void M1();
        string Zx{get; set;}
    }
}
