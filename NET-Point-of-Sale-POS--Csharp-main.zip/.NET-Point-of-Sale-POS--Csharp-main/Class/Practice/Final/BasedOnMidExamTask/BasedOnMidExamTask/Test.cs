﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasedOnMidExamTask
{
    internal partial class Test
    {
        internal void M1()
        {

        }
    }
}
