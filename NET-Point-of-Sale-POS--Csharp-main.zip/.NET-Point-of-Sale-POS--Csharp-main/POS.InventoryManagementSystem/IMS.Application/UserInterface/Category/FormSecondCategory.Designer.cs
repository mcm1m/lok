﻿
namespace FinalPoject
{
    partial class FormSecondCategory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlInsideTop = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.pnlInsideLeft = new Guna.UI2.WinForms.Guna2Panel();
            this.pnlBottom = new Guna.UI2.WinForms.Guna2Panel();
            this.pnlOrderSelect = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel8 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel7 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel6 = new Guna.UI2.WinForms.Guna2Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2Panel9 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.guna2Panel12 = new Guna.UI2.WinForms.Guna2Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAddMainCate = new Guna.UI2.WinForms.Guna2Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.cmbMainCate = new Guna.UI2.WinForms.Guna2ComboBox();
            this.txtSecondCateId = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtSecondDisc = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtSecondCateName = new Guna.UI2.WinForms.Guna2TextBox();
            this.btnRemoveProductPhoto = new Guna.UI2.WinForms.Guna2Button();
            this.btnAddProductPhoto = new Guna.UI2.WinForms.Guna2Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pbImage = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2TextBox11 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Panel10 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel20 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel62 = new Guna.UI2.WinForms.Guna2Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.btnCancle = new Guna.UI2.WinForms.Guna2Button();
            this.btnSave = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel15 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel16 = new Guna.UI2.WinForms.Guna2Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2Panel11 = new Guna.UI2.WinForms.Guna2Panel();
            this.dgvSecondCate = new System.Windows.Forms.DataGridView();
            this.guna2Panel28 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel26 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel18 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel21 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel13 = new Guna.UI2.WinForms.Guna2Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.btnRefresh = new Guna.UI2.WinForms.Guna2Button();
            this.btnDelete = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel5 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel22 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel27 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel14 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel17 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel23 = new Guna.UI2.WinForms.Guna2Panel();
            this.lableS = new System.Windows.Forms.Label();
            this.txtSearchCategories = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Panel24 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel25 = new Guna.UI2.WinForms.Guna2Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.SecondCategoryId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SecondCategoryName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SecondCategoryImage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MainCategoryName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlOrderSelect.SuspendLayout();
            this.guna2Panel2.SuspendLayout();
            this.guna2Panel6.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.guna2Panel12.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).BeginInit();
            this.guna2Panel62.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.guna2Panel15.SuspendLayout();
            this.guna2Panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSecondCate)).BeginInit();
            this.guna2Panel13.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.guna2Panel5.SuspendLayout();
            this.guna2Panel17.SuspendLayout();
            this.guna2Panel23.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlInsideTop
            // 
            this.pnlInsideTop.BackColor = System.Drawing.Color.Transparent;
            this.pnlInsideTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlInsideTop.Location = new System.Drawing.Point(0, 0);
            this.pnlInsideTop.Name = "pnlInsideTop";
            this.pnlInsideTop.ShadowDecoration.Parent = this.pnlInsideTop;
            this.pnlInsideTop.Size = new System.Drawing.Size(1244, 16);
            this.pnlInsideTop.TabIndex = 25;
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel3.Location = new System.Drawing.Point(1229, 16);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.ShadowDecoration.Parent = this.guna2Panel3;
            this.guna2Panel3.Size = new System.Drawing.Size(15, 715);
            this.guna2Panel3.TabIndex = 32;
            // 
            // pnlInsideLeft
            // 
            this.pnlInsideLeft.BackColor = System.Drawing.Color.Transparent;
            this.pnlInsideLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlInsideLeft.Location = new System.Drawing.Point(0, 16);
            this.pnlInsideLeft.Name = "pnlInsideLeft";
            this.pnlInsideLeft.ShadowDecoration.Parent = this.pnlInsideLeft;
            this.pnlInsideLeft.Size = new System.Drawing.Size(15, 715);
            this.pnlInsideLeft.TabIndex = 31;
            // 
            // pnlBottom
            // 
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 731);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.ShadowDecoration.Parent = this.pnlBottom;
            this.pnlBottom.Size = new System.Drawing.Size(1244, 16);
            this.pnlBottom.TabIndex = 30;
            // 
            // pnlOrderSelect
            // 
            this.pnlOrderSelect.BackColor = System.Drawing.Color.Transparent;
            this.pnlOrderSelect.BorderColor = System.Drawing.Color.Silver;
            this.pnlOrderSelect.BorderRadius = 12;
            this.pnlOrderSelect.BorderThickness = 1;
            this.pnlOrderSelect.Controls.Add(this.guna2Panel2);
            this.pnlOrderSelect.Controls.Add(this.guna2Panel6);
            this.pnlOrderSelect.CustomBorderColor = System.Drawing.Color.Silver;
            this.pnlOrderSelect.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlOrderSelect.FillColor = System.Drawing.Color.White;
            this.pnlOrderSelect.Location = new System.Drawing.Point(15, 16);
            this.pnlOrderSelect.Name = "pnlOrderSelect";
            this.pnlOrderSelect.ShadowDecoration.Parent = this.pnlOrderSelect;
            this.pnlOrderSelect.Size = new System.Drawing.Size(1214, 73);
            this.pnlOrderSelect.TabIndex = 33;
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.guna2Panel8);
            this.guna2Panel2.Controls.Add(this.guna2Panel7);
            this.guna2Panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel2.Location = new System.Drawing.Point(904, 0);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.ShadowDecoration.Parent = this.guna2Panel2;
            this.guna2Panel2.Size = new System.Drawing.Size(310, 73);
            this.guna2Panel2.TabIndex = 6;
            // 
            // guna2Panel8
            // 
            this.guna2Panel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel8.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel8.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel8.Name = "guna2Panel8";
            this.guna2Panel8.ShadowDecoration.Parent = this.guna2Panel8;
            this.guna2Panel8.Size = new System.Drawing.Size(20, 73);
            this.guna2Panel8.TabIndex = 18;
            // 
            // guna2Panel7
            // 
            this.guna2Panel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel7.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel7.Location = new System.Drawing.Point(290, 0);
            this.guna2Panel7.Name = "guna2Panel7";
            this.guna2Panel7.ShadowDecoration.Parent = this.guna2Panel7;
            this.guna2Panel7.Size = new System.Drawing.Size(20, 73);
            this.guna2Panel7.TabIndex = 17;
            // 
            // guna2Panel6
            // 
            this.guna2Panel6.Controls.Add(this.label3);
            this.guna2Panel6.Controls.Add(this.guna2Panel9);
            this.guna2Panel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel6.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel6.Name = "guna2Panel6";
            this.guna2Panel6.ShadowDecoration.Parent = this.guna2Panel6;
            this.guna2Panel6.Size = new System.Drawing.Size(542, 73);
            this.guna2Panel6.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(18, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(280, 39);
            this.label3.TabIndex = 20;
            this.label3.Text = "Second Category";
            // 
            // guna2Panel9
            // 
            this.guna2Panel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel9.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel9.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel9.Name = "guna2Panel9";
            this.guna2Panel9.ShadowDecoration.Parent = this.guna2Panel9;
            this.guna2Panel9.Size = new System.Drawing.Size(20, 73);
            this.guna2Panel9.TabIndex = 19;
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel1.Location = new System.Drawing.Point(15, 89);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(1214, 16);
            this.guna2Panel1.TabIndex = 34;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 450F));
            this.tableLayoutPanel1.Controls.Add(this.guna2Panel12, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2Panel11, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(15, 105);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1214, 626);
            this.tableLayoutPanel1.TabIndex = 35;
            // 
            // guna2Panel12
            // 
            this.guna2Panel12.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel12.BorderColor = System.Drawing.Color.Silver;
            this.guna2Panel12.BorderRadius = 12;
            this.guna2Panel12.BorderThickness = 1;
            this.guna2Panel12.Controls.Add(this.panel1);
            this.guna2Panel12.Controls.Add(this.guna2Panel10);
            this.guna2Panel12.Controls.Add(this.guna2Panel20);
            this.guna2Panel12.Controls.Add(this.guna2Panel62);
            this.guna2Panel12.Controls.Add(this.guna2Panel15);
            this.guna2Panel12.CustomBorderColor = System.Drawing.Color.Transparent;
            this.guna2Panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2Panel12.FillColor = System.Drawing.Color.White;
            this.guna2Panel12.Location = new System.Drawing.Point(767, 3);
            this.guna2Panel12.Name = "guna2Panel12";
            this.guna2Panel12.ShadowDecoration.Parent = this.guna2Panel12;
            this.guna2Panel12.Size = new System.Drawing.Size(444, 620);
            this.guna2Panel12.TabIndex = 25;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.btnAddMainCate);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.tableLayoutPanel2);
            this.panel1.Controls.Add(this.btnRemoveProductPhoto);
            this.panel1.Controls.Add(this.btnAddProductPhoto);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.pbImage);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.guna2TextBox11);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 70);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(444, 480);
            this.panel1.TabIndex = 153;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnAddMainCate
            // 
            this.btnAddMainCate.Animated = true;
            this.btnAddMainCate.CheckedState.Parent = this.btnAddMainCate;
            this.btnAddMainCate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddMainCate.CustomImages.HoveredImage = global::FinalPoject.Properties.Resources.icons8_plus_math_480px_1;
            this.btnAddMainCate.CustomImages.Image = global::FinalPoject.Properties.Resources.icons8_plus_math_480px;
            this.btnAddMainCate.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnAddMainCate.CustomImages.Parent = this.btnAddMainCate;
            this.btnAddMainCate.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(255)))), ((int)(((byte)(203)))));
            this.btnAddMainCate.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddMainCate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(173)))), ((int)(((byte)(27)))));
            this.btnAddMainCate.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(173)))), ((int)(((byte)(27)))));
            this.btnAddMainCate.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddMainCate.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnAddMainCate.HoverState.Parent = this.btnAddMainCate;
            this.btnAddMainCate.Location = new System.Drawing.Point(369, 351);
            this.btnAddMainCate.Name = "btnAddMainCate";
            this.btnAddMainCate.ShadowDecoration.Parent = this.btnAddMainCate;
            this.btnAddMainCate.Size = new System.Drawing.Size(35, 30);
            this.btnAddMainCate.TabIndex = 206;
            this.btnAddMainCate.TextOffset = new System.Drawing.Point(8, 0);
            this.btnAddMainCate.Click += new System.EventHandler(this.btnAddMainCate_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(58, 359);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 15);
            this.label2.TabIndex = 167;
            this.label2.Text = "Main Category ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(89, 415);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 15);
            this.label1.TabIndex = 166;
            this.label1.Text = "Discritption";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.cmbMainCate, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.txtSecondCateId, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.txtSecondDisc, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.txtSecondCateName, 0, 3);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(164, 236);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 9;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 122F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(200, 360);
            this.tableLayoutPanel2.TabIndex = 164;
            // 
            // cmbMainCate
            // 
            this.cmbMainCate.BackColor = System.Drawing.Color.Transparent;
            this.cmbMainCate.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbMainCate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMainCate.FocusedColor = System.Drawing.Color.Empty;
            this.cmbMainCate.FocusedState.Parent = this.cmbMainCate;
            this.cmbMainCate.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMainCate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbMainCate.FormattingEnabled = true;
            this.cmbMainCate.HoverState.Parent = this.cmbMainCate;
            this.cmbMainCate.ItemHeight = 30;
            this.cmbMainCate.ItemsAppearance.Parent = this.cmbMainCate;
            this.cmbMainCate.Location = new System.Drawing.Point(2, 112);
            this.cmbMainCate.Margin = new System.Windows.Forms.Padding(2);
            this.cmbMainCate.Name = "cmbMainCate";
            this.cmbMainCate.ShadowDecoration.Parent = this.cmbMainCate;
            this.cmbMainCate.Size = new System.Drawing.Size(196, 36);
            this.cmbMainCate.TabIndex = 183;
            // 
            // txtSecondCateId
            // 
            this.txtSecondCateId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSecondCateId.DefaultText = "";
            this.txtSecondCateId.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtSecondCateId.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtSecondCateId.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSecondCateId.DisabledState.Parent = this.txtSecondCateId;
            this.txtSecondCateId.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSecondCateId.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSecondCateId.FocusedState.Parent = this.txtSecondCateId;
            this.txtSecondCateId.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSecondCateId.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtSecondCateId.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSecondCateId.HoverState.Parent = this.txtSecondCateId;
            this.txtSecondCateId.Location = new System.Drawing.Point(3, 15);
            this.txtSecondCateId.Name = "txtSecondCateId";
            this.txtSecondCateId.PasswordChar = '\0';
            this.txtSecondCateId.PlaceholderText = "Auto Generate";
            this.txtSecondCateId.SelectedText = "";
            this.txtSecondCateId.ShadowDecoration.Parent = this.txtSecondCateId;
            this.txtSecondCateId.Size = new System.Drawing.Size(194, 30);
            this.txtSecondCateId.TabIndex = 55;
            // 
            // txtSecondDisc
            // 
            this.txtSecondDisc.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSecondDisc.DefaultText = "";
            this.txtSecondDisc.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtSecondDisc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtSecondDisc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSecondDisc.DisabledState.Parent = this.txtSecondDisc;
            this.txtSecondDisc.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSecondDisc.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSecondDisc.FocusedState.Parent = this.txtSecondDisc;
            this.txtSecondDisc.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSecondDisc.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtSecondDisc.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSecondDisc.HoverState.Parent = this.txtSecondDisc;
            this.txtSecondDisc.Location = new System.Drawing.Point(3, 162);
            this.txtSecondDisc.Multiline = true;
            this.txtSecondDisc.Name = "txtSecondDisc";
            this.txtSecondDisc.PasswordChar = '\0';
            this.txtSecondDisc.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtSecondDisc.PlaceholderText = "Ex: Products Details (Max 50 words)";
            this.txtSecondDisc.SelectedText = "";
            this.txtSecondDisc.ShadowDecoration.Parent = this.txtSecondDisc;
            this.txtSecondDisc.Size = new System.Drawing.Size(194, 115);
            this.txtSecondDisc.TabIndex = 146;
            // 
            // txtSecondCateName
            // 
            this.txtSecondCateName.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.txtSecondCateName.BackColor = System.Drawing.Color.Transparent;
            this.txtSecondCateName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSecondCateName.DefaultText = "";
            this.txtSecondCateName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtSecondCateName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtSecondCateName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSecondCateName.DisabledState.Parent = this.txtSecondCateName;
            this.txtSecondCateName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSecondCateName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSecondCateName.FocusedState.Parent = this.txtSecondCateName;
            this.txtSecondCateName.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSecondCateName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtSecondCateName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSecondCateName.HoverState.Parent = this.txtSecondCateName;
            this.txtSecondCateName.Location = new System.Drawing.Point(3, 64);
            this.txtSecondCateName.Name = "txtSecondCateName";
            this.txtSecondCateName.PasswordChar = '\0';
            this.txtSecondCateName.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.txtSecondCateName.PlaceholderText = "Ex: Chips, Coke, Mobile";
            this.txtSecondCateName.SelectedText = "";
            this.txtSecondCateName.ShadowDecoration.Parent = this.txtSecondCateName;
            this.txtSecondCateName.Size = new System.Drawing.Size(194, 30);
            this.txtSecondCateName.TabIndex = 56;
            // 
            // btnRemoveProductPhoto
            // 
            this.btnRemoveProductPhoto.Animated = true;
            this.btnRemoveProductPhoto.CheckedState.Parent = this.btnRemoveProductPhoto;
            this.btnRemoveProductPhoto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRemoveProductPhoto.CustomImages.HoveredImage = global::FinalPoject.Properties.Resources.icons8_remove_image_480px;
            this.btnRemoveProductPhoto.CustomImages.Image = global::FinalPoject.Properties.Resources.icons8_remove_image_480px_1;
            this.btnRemoveProductPhoto.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnRemoveProductPhoto.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnRemoveProductPhoto.CustomImages.Parent = this.btnRemoveProductPhoto;
            this.btnRemoveProductPhoto.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(229)))));
            this.btnRemoveProductPhoto.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveProductPhoto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnRemoveProductPhoto.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnRemoveProductPhoto.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveProductPhoto.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnRemoveProductPhoto.HoverState.Parent = this.btnRemoveProductPhoto;
            this.btnRemoveProductPhoto.Location = new System.Drawing.Point(202, 142);
            this.btnRemoveProductPhoto.Name = "btnRemoveProductPhoto";
            this.btnRemoveProductPhoto.ShadowDecoration.Parent = this.btnRemoveProductPhoto;
            this.btnRemoveProductPhoto.Size = new System.Drawing.Size(190, 37);
            this.btnRemoveProductPhoto.TabIndex = 133;
            this.btnRemoveProductPhoto.Text = "Remove";
            this.btnRemoveProductPhoto.TextOffset = new System.Drawing.Point(12, 0);
            // 
            // btnAddProductPhoto
            // 
            this.btnAddProductPhoto.Animated = true;
            this.btnAddProductPhoto.CheckedState.Parent = this.btnAddProductPhoto;
            this.btnAddProductPhoto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddProductPhoto.CustomImages.HoveredImage = global::FinalPoject.Properties.Resources.icons8_edit_image_480px;
            this.btnAddProductPhoto.CustomImages.Image = global::FinalPoject.Properties.Resources.icons8_edit_image_480px_1;
            this.btnAddProductPhoto.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnAddProductPhoto.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnAddProductPhoto.CustomImages.Parent = this.btnAddProductPhoto;
            this.btnAddProductPhoto.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(255)))), ((int)(((byte)(203)))));
            this.btnAddProductPhoto.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProductPhoto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(173)))), ((int)(((byte)(27)))));
            this.btnAddProductPhoto.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(173)))), ((int)(((byte)(27)))));
            this.btnAddProductPhoto.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProductPhoto.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnAddProductPhoto.HoverState.Parent = this.btnAddProductPhoto;
            this.btnAddProductPhoto.Location = new System.Drawing.Point(202, 95);
            this.btnAddProductPhoto.Name = "btnAddProductPhoto";
            this.btnAddProductPhoto.ShadowDecoration.Parent = this.btnAddProductPhoto;
            this.btnAddProductPhoto.Size = new System.Drawing.Size(190, 37);
            this.btnAddProductPhoto.TabIndex = 132;
            this.btnAddProductPhoto.Text = "Add";
            this.btnAddProductPhoto.TextOffset = new System.Drawing.Point(8, 0);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(46, 258);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 15);
            this.label8.TabIndex = 44;
            this.label8.Text = "Second Category ID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(22, 308);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 15);
            this.label7.TabIndex = 45;
            this.label7.Text = "Second  Category Name";
            // 
            // pbImage
            // 
            this.pbImage.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pbImage.ErrorImage = global::FinalPoject.Properties.Resources.icons8_no_image_480px_2;
            this.pbImage.Image = global::FinalPoject.Properties.Resources.icons8_add_camera_480px;
            this.pbImage.Location = new System.Drawing.Point(35, 20);
            this.pbImage.Margin = new System.Windows.Forms.Padding(2);
            this.pbImage.Name = "pbImage";
            this.pbImage.ShadowDecoration.Parent = this.pbImage;
            this.pbImage.Size = new System.Drawing.Size(150, 162);
            this.pbImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbImage.TabIndex = 148;
            this.pbImage.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(198, 24);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 20);
            this.label9.TabIndex = 147;
            this.label9.Text = "File Name";
            // 
            // guna2TextBox11
            // 
            this.guna2TextBox11.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox11.DefaultText = "";
            this.guna2TextBox11.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox11.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox11.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox11.DisabledState.Parent = this.guna2TextBox11;
            this.guna2TextBox11.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox11.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox11.FocusedState.Parent = this.guna2TextBox11;
            this.guna2TextBox11.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2TextBox11.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox11.HoverState.Parent = this.guna2TextBox11;
            this.guna2TextBox11.Location = new System.Drawing.Point(202, 49);
            this.guna2TextBox11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.guna2TextBox11.Name = "guna2TextBox11";
            this.guna2TextBox11.PasswordChar = '\0';
            this.guna2TextBox11.PlaceholderText = "filename.jpg/png";
            this.guna2TextBox11.SelectedText = "";
            this.guna2TextBox11.ShadowDecoration.Parent = this.guna2TextBox11;
            this.guna2TextBox11.Size = new System.Drawing.Size(190, 32);
            this.guna2TextBox11.TabIndex = 146;
            // 
            // guna2Panel10
            // 
            this.guna2Panel10.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel10.Location = new System.Drawing.Point(0, 550);
            this.guna2Panel10.Name = "guna2Panel10";
            this.guna2Panel10.ShadowDecoration.Parent = this.guna2Panel10;
            this.guna2Panel10.Size = new System.Drawing.Size(444, 13);
            this.guna2Panel10.TabIndex = 142;
            // 
            // guna2Panel20
            // 
            this.guna2Panel20.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel20.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel20.Location = new System.Drawing.Point(0, 57);
            this.guna2Panel20.Name = "guna2Panel20";
            this.guna2Panel20.ShadowDecoration.Parent = this.guna2Panel20;
            this.guna2Panel20.Size = new System.Drawing.Size(444, 13);
            this.guna2Panel20.TabIndex = 139;
            // 
            // guna2Panel62
            // 
            this.guna2Panel62.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel62.Controls.Add(this.tableLayoutPanel3);
            this.guna2Panel62.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel62.CustomBorderThickness = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.guna2Panel62.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel62.Location = new System.Drawing.Point(0, 563);
            this.guna2Panel62.Name = "guna2Panel62";
            this.guna2Panel62.ShadowDecoration.Parent = this.guna2Panel62;
            this.guna2Panel62.Size = new System.Drawing.Size(444, 57);
            this.guna2Panel62.TabIndex = 132;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.btnCancle, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.btnSave, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(444, 57);
            this.tableLayoutPanel3.TabIndex = 135;
            // 
            // btnCancle
            // 
            this.btnCancle.Animated = true;
            this.btnCancle.CheckedState.Parent = this.btnCancle;
            this.btnCancle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancle.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnCancle.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnCancle.CustomImages.Parent = this.btnCancle;
            this.btnCancle.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnCancle.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(229)))));
            this.btnCancle.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnCancle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnCancle.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnCancle.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnCancle.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnCancle.HoverState.Parent = this.btnCancle;
            this.btnCancle.Location = new System.Drawing.Point(229, 11);
            this.btnCancle.Name = "btnCancle";
            this.btnCancle.ShadowDecoration.Parent = this.btnCancle;
            this.btnCancle.Size = new System.Drawing.Size(142, 35);
            this.btnCancle.TabIndex = 117;
            this.btnCancle.Text = "Cancel";
            this.btnCancle.Click += new System.EventHandler(this.btnCancle_Click);
            // 
            // btnSave
            // 
            this.btnSave.Animated = true;
            this.btnSave.CheckedState.Parent = this.btnSave;
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSave.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnSave.CustomImages.Parent = this.btnSave;
            this.btnSave.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSave.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(153)))), ((int)(((byte)(255)))));
            this.btnSave.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(153)))), ((int)(((byte)(255)))));
            this.btnSave.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnSave.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnSave.HoverState.Parent = this.btnSave;
            this.btnSave.Location = new System.Drawing.Point(73, 11);
            this.btnSave.Name = "btnSave";
            this.btnSave.ShadowDecoration.Parent = this.btnSave;
            this.btnSave.Size = new System.Drawing.Size(142, 35);
            this.btnSave.TabIndex = 118;
            this.btnSave.Text = "Save";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // guna2Panel15
            // 
            this.guna2Panel15.Controls.Add(this.guna2Panel16);
            this.guna2Panel15.Controls.Add(this.label5);
            this.guna2Panel15.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel15.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.guna2Panel15.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel15.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel15.Name = "guna2Panel15";
            this.guna2Panel15.ShadowDecoration.Parent = this.guna2Panel15;
            this.guna2Panel15.Size = new System.Drawing.Size(444, 57);
            this.guna2Panel15.TabIndex = 130;
            // 
            // guna2Panel16
            // 
            this.guna2Panel16.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel16.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel16.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel16.Name = "guna2Panel16";
            this.guna2Panel16.ShadowDecoration.Parent = this.guna2Panel16;
            this.guna2Panel16.Size = new System.Drawing.Size(20, 57);
            this.guna2Panel16.TabIndex = 19;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(26, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(183, 21);
            this.label5.TabIndex = 0;
            this.label5.Text = "Add Second Categories";
            // 
            // guna2Panel11
            // 
            this.guna2Panel11.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel11.BorderColor = System.Drawing.Color.Silver;
            this.guna2Panel11.BorderRadius = 12;
            this.guna2Panel11.BorderThickness = 1;
            this.guna2Panel11.Controls.Add(this.dgvSecondCate);
            this.guna2Panel11.Controls.Add(this.guna2Panel28);
            this.guna2Panel11.Controls.Add(this.guna2Panel26);
            this.guna2Panel11.Controls.Add(this.guna2Panel18);
            this.guna2Panel11.Controls.Add(this.guna2Panel21);
            this.guna2Panel11.Controls.Add(this.guna2Panel13);
            this.guna2Panel11.Controls.Add(this.guna2Panel5);
            this.guna2Panel11.Controls.Add(this.guna2Panel17);
            this.guna2Panel11.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2Panel11.FillColor = System.Drawing.Color.White;
            this.guna2Panel11.Location = new System.Drawing.Point(3, 3);
            this.guna2Panel11.Name = "guna2Panel11";
            this.guna2Panel11.ShadowDecoration.Parent = this.guna2Panel11;
            this.guna2Panel11.Size = new System.Drawing.Size(743, 620);
            this.guna2Panel11.TabIndex = 27;
            // 
            // dgvSecondCate
            // 
            this.dgvSecondCate.AllowUserToAddRows = false;
            this.dgvSecondCate.AllowUserToDeleteRows = false;
            this.dgvSecondCate.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvSecondCate.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSecondCate.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SecondCategoryId,
            this.SecondCategoryName,
            this.SecondCategoryImage,
            this.MainCategoryName});
            this.dgvSecondCate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSecondCate.Location = new System.Drawing.Point(8, 154);
            this.dgvSecondCate.Margin = new System.Windows.Forms.Padding(2);
            this.dgvSecondCate.Name = "dgvSecondCate";
            this.dgvSecondCate.ReadOnly = true;
            this.dgvSecondCate.RowHeadersWidth = 51;
            this.dgvSecondCate.RowTemplate.Height = 24;
            this.dgvSecondCate.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSecondCate.Size = new System.Drawing.Size(727, 401);
            this.dgvSecondCate.TabIndex = 160;
            this.dgvSecondCate.DoubleClick += new System.EventHandler(this.dgvSecondCate_DoubleClick);
            // 
            // guna2Panel28
            // 
            this.guna2Panel28.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel28.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel28.Location = new System.Drawing.Point(8, 555);
            this.guna2Panel28.Name = "guna2Panel28";
            this.guna2Panel28.ShadowDecoration.Parent = this.guna2Panel28;
            this.guna2Panel28.Size = new System.Drawing.Size(727, 8);
            this.guna2Panel28.TabIndex = 159;
            // 
            // guna2Panel26
            // 
            this.guna2Panel26.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel26.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel26.Location = new System.Drawing.Point(735, 154);
            this.guna2Panel26.Name = "guna2Panel26";
            this.guna2Panel26.ShadowDecoration.Parent = this.guna2Panel26;
            this.guna2Panel26.Size = new System.Drawing.Size(8, 409);
            this.guna2Panel26.TabIndex = 156;
            // 
            // guna2Panel18
            // 
            this.guna2Panel18.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel18.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel18.Location = new System.Drawing.Point(0, 154);
            this.guna2Panel18.Name = "guna2Panel18";
            this.guna2Panel18.ShadowDecoration.Parent = this.guna2Panel18;
            this.guna2Panel18.Size = new System.Drawing.Size(8, 409);
            this.guna2Panel18.TabIndex = 155;
            // 
            // guna2Panel21
            // 
            this.guna2Panel21.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel21.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel21.Location = new System.Drawing.Point(0, 146);
            this.guna2Panel21.Name = "guna2Panel21";
            this.guna2Panel21.ShadowDecoration.Parent = this.guna2Panel21;
            this.guna2Panel21.Size = new System.Drawing.Size(743, 8);
            this.guna2Panel21.TabIndex = 154;
            // 
            // guna2Panel13
            // 
            this.guna2Panel13.Controls.Add(this.tableLayoutPanel4);
            this.guna2Panel13.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel13.CustomBorderThickness = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.guna2Panel13.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel13.Location = new System.Drawing.Point(0, 563);
            this.guna2Panel13.Name = "guna2Panel13";
            this.guna2Panel13.ShadowDecoration.Parent = this.guna2Panel13;
            this.guna2Panel13.Size = new System.Drawing.Size(743, 57);
            this.guna2Panel13.TabIndex = 133;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 5;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 225F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 225F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.btnRefresh, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.btnDelete, 3, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 3;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(743, 57);
            this.tableLayoutPanel4.TabIndex = 137;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Animated = true;
            this.btnRefresh.CheckedState.Parent = this.btnRefresh;
            this.btnRefresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefresh.CustomImages.HoveredImage = global::FinalPoject.Properties.Resources.icons8_restart_96px_1;
            this.btnRefresh.CustomImages.Image = global::FinalPoject.Properties.Resources.icons8_restart_96px;
            this.btnRefresh.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnRefresh.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnRefresh.CustomImages.Parent = this.btnRefresh;
            this.btnRefresh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRefresh.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(233)))), ((int)(((byte)(249)))));
            this.btnRefresh.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(148)))), ((int)(((byte)(247)))));
            this.btnRefresh.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(148)))), ((int)(((byte)(247)))));
            this.btnRefresh.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(233)))), ((int)(((byte)(249)))));
            this.btnRefresh.HoverState.Parent = this.btnRefresh;
            this.btnRefresh.Location = new System.Drawing.Point(145, 11);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.ShadowDecoration.Parent = this.btnRefresh;
            this.btnRefresh.Size = new System.Drawing.Size(219, 35);
            this.btnRefresh.TabIndex = 133;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.TextOffset = new System.Drawing.Point(8, 0);
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Animated = true;
            this.btnDelete.CheckedState.Parent = this.btnDelete;
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.CustomImages.HoveredImage = global::FinalPoject.Properties.Resources.icons8_trash_can_480px;
            this.btnDelete.CustomImages.Image = global::FinalPoject.Properties.Resources.icons8_trash_can_480px_1;
            this.btnDelete.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnDelete.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnDelete.CustomImages.Parent = this.btnDelete;
            this.btnDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDelete.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(229)))));
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnDelete.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnDelete.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnDelete.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnDelete.HoverState.Parent = this.btnDelete;
            this.btnDelete.Location = new System.Drawing.Point(378, 11);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.ShadowDecoration.Parent = this.btnDelete;
            this.btnDelete.Size = new System.Drawing.Size(219, 35);
            this.btnDelete.TabIndex = 135;
            this.btnDelete.Text = "Delete";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // guna2Panel5
            // 
            this.guna2Panel5.Controls.Add(this.guna2Panel22);
            this.guna2Panel5.Controls.Add(this.guna2Panel27);
            this.guna2Panel5.Controls.Add(this.guna2Panel14);
            this.guna2Panel5.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel5.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.guna2Panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel5.Location = new System.Drawing.Point(0, 57);
            this.guna2Panel5.Name = "guna2Panel5";
            this.guna2Panel5.ShadowDecoration.Parent = this.guna2Panel5;
            this.guna2Panel5.Size = new System.Drawing.Size(743, 89);
            this.guna2Panel5.TabIndex = 132;
            // 
            // guna2Panel22
            // 
            this.guna2Panel22.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel22.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel22.Location = new System.Drawing.Point(20, 81);
            this.guna2Panel22.Name = "guna2Panel22";
            this.guna2Panel22.ShadowDecoration.Parent = this.guna2Panel22;
            this.guna2Panel22.Size = new System.Drawing.Size(703, 8);
            this.guna2Panel22.TabIndex = 182;
            // 
            // guna2Panel27
            // 
            this.guna2Panel27.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel27.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel27.Location = new System.Drawing.Point(723, 0);
            this.guna2Panel27.Name = "guna2Panel27";
            this.guna2Panel27.ShadowDecoration.Parent = this.guna2Panel27;
            this.guna2Panel27.Size = new System.Drawing.Size(20, 89);
            this.guna2Panel27.TabIndex = 20;
            // 
            // guna2Panel14
            // 
            this.guna2Panel14.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel14.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel14.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel14.Name = "guna2Panel14";
            this.guna2Panel14.ShadowDecoration.Parent = this.guna2Panel14;
            this.guna2Panel14.Size = new System.Drawing.Size(20, 89);
            this.guna2Panel14.TabIndex = 19;
            // 
            // guna2Panel17
            // 
            this.guna2Panel17.Controls.Add(this.guna2Panel23);
            this.guna2Panel17.Controls.Add(this.guna2Panel25);
            this.guna2Panel17.Controls.Add(this.label6);
            this.guna2Panel17.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel17.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.guna2Panel17.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel17.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel17.Name = "guna2Panel17";
            this.guna2Panel17.ShadowDecoration.Parent = this.guna2Panel17;
            this.guna2Panel17.Size = new System.Drawing.Size(743, 57);
            this.guna2Panel17.TabIndex = 131;
            // 
            // guna2Panel23
            // 
            this.guna2Panel23.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel23.Controls.Add(this.lableS);
            this.guna2Panel23.Controls.Add(this.txtSearchCategories);
            this.guna2Panel23.Controls.Add(this.guna2Panel24);
            this.guna2Panel23.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel23.Location = new System.Drawing.Point(176, 0);
            this.guna2Panel23.Name = "guna2Panel23";
            this.guna2Panel23.ShadowDecoration.Parent = this.guna2Panel23;
            this.guna2Panel23.Size = new System.Drawing.Size(567, 57);
            this.guna2Panel23.TabIndex = 24;
            // 
            // lableS
            // 
            this.lableS.AutoSize = true;
            this.lableS.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lableS.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.lableS.Location = new System.Drawing.Point(170, 19);
            this.lableS.Margin = new System.Windows.Forms.Padding(0);
            this.lableS.Name = "lableS";
            this.lableS.Size = new System.Drawing.Size(118, 19);
            this.lableS.TabIndex = 168;
            this.lableS.Text = "Search Categories";
            // 
            // txtSearchCategories
            // 
            this.txtSearchCategories.AccessibleRole = System.Windows.Forms.AccessibleRole.Grip;
            this.txtSearchCategories.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSearchCategories.DefaultText = "";
            this.txtSearchCategories.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtSearchCategories.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtSearchCategories.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSearchCategories.DisabledState.Parent = this.txtSearchCategories;
            this.txtSearchCategories.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSearchCategories.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSearchCategories.FocusedState.Parent = this.txtSearchCategories;
            this.txtSearchCategories.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchCategories.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSearchCategories.HoverState.Parent = this.txtSearchCategories;
            this.txtSearchCategories.HoverState.PlaceholderForeColor = System.Drawing.Color.Transparent;
            this.txtSearchCategories.IconRight = global::FinalPoject.Properties.Resources.icons8_search_480px;
            this.txtSearchCategories.Location = new System.Drawing.Point(300, 13);
            this.txtSearchCategories.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtSearchCategories.Name = "txtSearchCategories";
            this.txtSearchCategories.PasswordChar = '\0';
            this.txtSearchCategories.PlaceholderText = "by Name, Tag, Cate. Brand";
            this.txtSearchCategories.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtSearchCategories.SelectedText = "";
            this.txtSearchCategories.ShadowDecoration.Parent = this.txtSearchCategories;
            this.txtSearchCategories.Size = new System.Drawing.Size(245, 30);
            this.txtSearchCategories.TabIndex = 167;
            this.txtSearchCategories.TextChanged += new System.EventHandler(this.txtSearchCategories_TextChanged_1);
            // 
            // guna2Panel24
            // 
            this.guna2Panel24.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel24.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel24.Location = new System.Drawing.Point(547, 0);
            this.guna2Panel24.Name = "guna2Panel24";
            this.guna2Panel24.ShadowDecoration.Parent = this.guna2Panel24;
            this.guna2Panel24.Size = new System.Drawing.Size(20, 57);
            this.guna2Panel24.TabIndex = 135;
            // 
            // guna2Panel25
            // 
            this.guna2Panel25.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel25.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel25.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel25.Name = "guna2Panel25";
            this.guna2Panel25.ShadowDecoration.Parent = this.guna2Panel25;
            this.guna2Panel25.Size = new System.Drawing.Size(20, 57);
            this.guna2Panel25.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(26, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(151, 21);
            this.label6.TabIndex = 0;
            this.label6.Text = "View All Categories";
            // 
            // SecondCategoryId
            // 
            this.SecondCategoryId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SecondCategoryId.DataPropertyName = "SecondCategoryId";
            this.SecondCategoryId.HeaderText = "Second Category ID";
            this.SecondCategoryId.MinimumWidth = 6;
            this.SecondCategoryId.Name = "SecondCategoryId";
            this.SecondCategoryId.ReadOnly = true;
            // 
            // SecondCategoryName
            // 
            this.SecondCategoryName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SecondCategoryName.DataPropertyName = "SecondCategoryName";
            this.SecondCategoryName.HeaderText = "Second Category Name";
            this.SecondCategoryName.MinimumWidth = 6;
            this.SecondCategoryName.Name = "SecondCategoryName";
            this.SecondCategoryName.ReadOnly = true;
            // 
            // SecondCategoryImage
            // 
            this.SecondCategoryImage.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SecondCategoryImage.DataPropertyName = "SecondCategoryImage";
            this.SecondCategoryImage.HeaderText = "Second Category Picture";
            this.SecondCategoryImage.MinimumWidth = 6;
            this.SecondCategoryImage.Name = "SecondCategoryImage";
            this.SecondCategoryImage.ReadOnly = true;
            this.SecondCategoryImage.Visible = false;
            // 
            // MainCategoryName
            // 
            this.MainCategoryName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.MainCategoryName.DataPropertyName = "MainCategoryName";
            this.MainCategoryName.HeaderText = "Main Category Name";
            this.MainCategoryName.Name = "MainCategoryName";
            this.MainCategoryName.ReadOnly = true;
            // 
            // FormSecondCategory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1244, 747);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.guna2Panel1);
            this.Controls.Add(this.pnlOrderSelect);
            this.Controls.Add(this.guna2Panel3);
            this.Controls.Add(this.pnlInsideLeft);
            this.Controls.Add(this.pnlBottom);
            this.Controls.Add(this.pnlInsideTop);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1260, 786);
            this.Name = "FormSecondCategory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SecondCategory";
            this.Load += new System.EventHandler(this.FormSecondCategory_Load);
            this.pnlOrderSelect.ResumeLayout(false);
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel6.ResumeLayout(false);
            this.guna2Panel6.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.guna2Panel12.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).EndInit();
            this.guna2Panel62.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.guna2Panel15.ResumeLayout(false);
            this.guna2Panel15.PerformLayout();
            this.guna2Panel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSecondCate)).EndInit();
            this.guna2Panel13.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.guna2Panel5.ResumeLayout(false);
            this.guna2Panel17.ResumeLayout(false);
            this.guna2Panel17.PerformLayout();
            this.guna2Panel23.ResumeLayout(false);
            this.guna2Panel23.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel pnlInsideTop;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2Panel pnlInsideLeft;
        private Guna.UI2.WinForms.Guna2Panel pnlBottom;
        private Guna.UI2.WinForms.Guna2Panel pnlOrderSelect;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel8;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel7;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel6;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel9;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel12;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private Guna.UI2.WinForms.Guna2TextBox txtSecondCateId;
        private Guna.UI2.WinForms.Guna2TextBox txtSecondDisc;
        private Guna.UI2.WinForms.Guna2TextBox txtSecondCateName;
        private Guna.UI2.WinForms.Guna2Button btnRemoveProductPhoto;
        private Guna.UI2.WinForms.Guna2Button btnAddProductPhoto;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2PictureBox pbImage;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox11;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel10;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel20;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel62;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private Guna.UI2.WinForms.Guna2Button btnCancle;
        private Guna.UI2.WinForms.Guna2Button btnSave;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel15;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel16;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel11;
        private System.Windows.Forms.DataGridView dgvSecondCate;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel28;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel26;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel18;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel21;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private Guna.UI2.WinForms.Guna2Button btnRefresh;
        private Guna.UI2.WinForms.Guna2Button btnDelete;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel22;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel27;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel14;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel17;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel25;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2ComboBox cmbMainCate;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel23;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel24;
        private System.Windows.Forms.Label lableS;
        private Guna.UI2.WinForms.Guna2TextBox txtSearchCategories;
        private Guna.UI2.WinForms.Guna2Button btnAddMainCate;
        private System.Windows.Forms.DataGridViewTextBoxColumn SecondCategoryId;
        private System.Windows.Forms.DataGridViewTextBoxColumn SecondCategoryName;
        private System.Windows.Forms.DataGridViewTextBoxColumn SecondCategoryImage;
        private System.Windows.Forms.DataGridViewTextBoxColumn MainCategoryName;
    }
}