﻿
namespace FinalPoject
{
    partial class FormBrand
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.guna2Panel12 = new Guna.UI2.WinForms.Guna2Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAddVendors = new Guna.UI2.WinForms.Guna2Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.txtBrandStatus = new Guna.UI2.WinForms.Guna2TextBox();
            this.cmbVendor = new Guna.UI2.WinForms.Guna2ComboBox();
            this.txtBrandTag = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtBrandId = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtBrandDisc = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtBrandName = new Guna.UI2.WinForms.Guna2TextBox();
            this.btnRemoveProductPhoto = new Guna.UI2.WinForms.Guna2Button();
            this.btnAddProductPhoto = new Guna.UI2.WinForms.Guna2Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pbmage = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2TextBox11 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Panel10 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel20 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel62 = new Guna.UI2.WinForms.Guna2Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.btnCancle = new Guna.UI2.WinForms.Guna2Button();
            this.btnSaveBrand = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel15 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel16 = new Guna.UI2.WinForms.Guna2Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2Panel11 = new Guna.UI2.WinForms.Guna2Panel();
            this.dgvBrand = new System.Windows.Forms.DataGridView();
            this.BrandId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BrandTag = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BrandName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VendorName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BrandStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BrandDisc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VendorId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.guna2Panel28 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel26 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel18 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel21 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel13 = new Guna.UI2.WinForms.Guna2Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.btnBrandRefresh = new Guna.UI2.WinForms.Guna2Button();
            this.btnDeleteBrand = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel5 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel22 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel27 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel14 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel17 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel23 = new Guna.UI2.WinForms.Guna2Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.txtSearchBrand = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Panel24 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel25 = new Guna.UI2.WinForms.Guna2Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.pnlOrderSelect = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel8 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel7 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel6 = new Guna.UI2.WinForms.Guna2Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2Panel9 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.pnlInsideLeft = new Guna.UI2.WinForms.Guna2Panel();
            this.pnlBottom = new Guna.UI2.WinForms.Guna2Panel();
            this.pnlInsideTop = new Guna.UI2.WinForms.Guna2Panel();
            this.tableLayoutPanel1.SuspendLayout();
            this.guna2Panel12.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbmage)).BeginInit();
            this.guna2Panel62.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.guna2Panel15.SuspendLayout();
            this.guna2Panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBrand)).BeginInit();
            this.guna2Panel13.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.guna2Panel5.SuspendLayout();
            this.guna2Panel17.SuspendLayout();
            this.guna2Panel23.SuspendLayout();
            this.pnlOrderSelect.SuspendLayout();
            this.guna2Panel2.SuspendLayout();
            this.guna2Panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 420F));
            this.tableLayoutPanel1.Controls.Add(this.guna2Panel12, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2Panel11, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(15, 105);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1214, 626);
            this.tableLayoutPanel1.TabIndex = 42;
            // 
            // guna2Panel12
            // 
            this.guna2Panel12.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel12.BorderColor = System.Drawing.Color.Silver;
            this.guna2Panel12.BorderRadius = 12;
            this.guna2Panel12.BorderThickness = 1;
            this.guna2Panel12.Controls.Add(this.panel1);
            this.guna2Panel12.Controls.Add(this.guna2Panel10);
            this.guna2Panel12.Controls.Add(this.guna2Panel20);
            this.guna2Panel12.Controls.Add(this.guna2Panel62);
            this.guna2Panel12.Controls.Add(this.guna2Panel15);
            this.guna2Panel12.CustomBorderColor = System.Drawing.Color.Transparent;
            this.guna2Panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2Panel12.FillColor = System.Drawing.Color.White;
            this.guna2Panel12.Location = new System.Drawing.Point(797, 3);
            this.guna2Panel12.Name = "guna2Panel12";
            this.guna2Panel12.ShadowDecoration.Parent = this.guna2Panel12;
            this.guna2Panel12.Size = new System.Drawing.Size(414, 620);
            this.guna2Panel12.TabIndex = 25;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.btnAddVendors);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label26);
            this.panel1.Controls.Add(this.tableLayoutPanel2);
            this.panel1.Controls.Add(this.btnRemoveProductPhoto);
            this.panel1.Controls.Add(this.btnAddProductPhoto);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.pbmage);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.guna2TextBox11);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 70);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(414, 480);
            this.panel1.TabIndex = 153;
            // 
            // btnAddVendors
            // 
            this.btnAddVendors.Animated = true;
            this.btnAddVendors.CheckedState.Parent = this.btnAddVendors;
            this.btnAddVendors.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddVendors.CustomImages.HoveredImage = global::FinalPoject.Properties.Resources.icons8_plus_math_480px_1;
            this.btnAddVendors.CustomImages.Image = global::FinalPoject.Properties.Resources.icons8_plus_math_480px;
            this.btnAddVendors.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnAddVendors.CustomImages.Parent = this.btnAddVendors;
            this.btnAddVendors.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(255)))), ((int)(((byte)(203)))));
            this.btnAddVendors.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddVendors.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(173)))), ((int)(((byte)(27)))));
            this.btnAddVendors.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(173)))), ((int)(((byte)(27)))));
            this.btnAddVendors.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddVendors.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnAddVendors.HoverState.Parent = this.btnAddVendors;
            this.btnAddVendors.Location = new System.Drawing.Point(339, 399);
            this.btnAddVendors.Name = "btnAddVendors";
            this.btnAddVendors.ShadowDecoration.Parent = this.btnAddVendors;
            this.btnAddVendors.Size = new System.Drawing.Size(35, 30);
            this.btnAddVendors.TabIndex = 206;
            this.btnAddVendors.TextOffset = new System.Drawing.Point(8, 0);
            this.btnAddVendors.Click += new System.EventHandler(this.btnAddVendors_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(80, 458);
            this.label10.Margin = new System.Windows.Forms.Padding(0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 15);
            this.label10.TabIndex = 169;
            this.label10.Text = "Status";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(40, 408);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 15);
            this.label2.TabIndex = 167;
            this.label2.Text = "Vendor Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(51, 509);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 15);
            this.label1.TabIndex = 166;
            this.label1.Text = "Discritption";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(57, 309);
            this.label26.Margin = new System.Windows.Forms.Padding(0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(62, 15);
            this.label26.TabIndex = 165;
            this.label26.Text = "Brand TAG";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.txtBrandStatus, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.cmbVendor, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.txtBrandTag, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.txtBrandId, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.txtBrandDisc, 0, 11);
            this.tableLayoutPanel2.Controls.Add(this.txtBrandName, 0, 5);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(132, 236);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 13;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 122F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(200, 429);
            this.tableLayoutPanel2.TabIndex = 164;
            // 
            // txtBrandStatus
            // 
            this.txtBrandStatus.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.txtBrandStatus.BackColor = System.Drawing.Color.Transparent;
            this.txtBrandStatus.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBrandStatus.DefaultText = "";
            this.txtBrandStatus.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtBrandStatus.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtBrandStatus.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtBrandStatus.DisabledState.Parent = this.txtBrandStatus;
            this.txtBrandStatus.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtBrandStatus.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtBrandStatus.FocusedState.Parent = this.txtBrandStatus;
            this.txtBrandStatus.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBrandStatus.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtBrandStatus.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtBrandStatus.HoverState.Parent = this.txtBrandStatus;
            this.txtBrandStatus.Location = new System.Drawing.Point(3, 211);
            this.txtBrandStatus.Name = "txtBrandStatus";
            this.txtBrandStatus.PasswordChar = '\0';
            this.txtBrandStatus.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.txtBrandStatus.PlaceholderText = "Brand:  Coca cola, Lays";
            this.txtBrandStatus.SelectedText = "";
            this.txtBrandStatus.ShadowDecoration.Parent = this.txtBrandStatus;
            this.txtBrandStatus.Size = new System.Drawing.Size(194, 30);
            this.txtBrandStatus.TabIndex = 163;
            // 
            // cmbVendor
            // 
            this.cmbVendor.BackColor = System.Drawing.Color.Transparent;
            this.cmbVendor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbVendor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVendor.FocusedColor = System.Drawing.Color.Empty;
            this.cmbVendor.FocusedState.Parent = this.cmbVendor;
            this.cmbVendor.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbVendor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbVendor.FormattingEnabled = true;
            this.cmbVendor.HoverState.Parent = this.cmbVendor;
            this.cmbVendor.ItemHeight = 30;
            this.cmbVendor.ItemsAppearance.Parent = this.cmbVendor;
            this.cmbVendor.Location = new System.Drawing.Point(2, 161);
            this.cmbVendor.Margin = new System.Windows.Forms.Padding(2);
            this.cmbVendor.Name = "cmbVendor";
            this.cmbVendor.ShadowDecoration.Parent = this.cmbVendor;
            this.cmbVendor.Size = new System.Drawing.Size(196, 36);
            this.cmbVendor.TabIndex = 183;
            // 
            // txtBrandTag
            // 
            this.txtBrandTag.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBrandTag.DefaultText = "";
            this.txtBrandTag.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtBrandTag.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtBrandTag.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtBrandTag.DisabledState.Parent = this.txtBrandTag;
            this.txtBrandTag.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtBrandTag.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtBrandTag.FocusedState.Parent = this.txtBrandTag;
            this.txtBrandTag.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBrandTag.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtBrandTag.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtBrandTag.HoverState.Parent = this.txtBrandTag;
            this.txtBrandTag.Location = new System.Drawing.Point(3, 64);
            this.txtBrandTag.Name = "txtBrandTag";
            this.txtBrandTag.PasswordChar = '\0';
            this.txtBrandTag.PlaceholderText = "Auto Generate";
            this.txtBrandTag.SelectedText = "";
            this.txtBrandTag.ShadowDecoration.Parent = this.txtBrandTag;
            this.txtBrandTag.Size = new System.Drawing.Size(194, 30);
            this.txtBrandTag.TabIndex = 167;
            // 
            // txtBrandId
            // 
            this.txtBrandId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBrandId.DefaultText = "";
            this.txtBrandId.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtBrandId.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtBrandId.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtBrandId.DisabledState.Parent = this.txtBrandId;
            this.txtBrandId.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtBrandId.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtBrandId.FocusedState.Parent = this.txtBrandId;
            this.txtBrandId.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBrandId.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtBrandId.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtBrandId.HoverState.Parent = this.txtBrandId;
            this.txtBrandId.Location = new System.Drawing.Point(3, 15);
            this.txtBrandId.Name = "txtBrandId";
            this.txtBrandId.PasswordChar = '\0';
            this.txtBrandId.PlaceholderText = "Auto Generate";
            this.txtBrandId.SelectedText = "";
            this.txtBrandId.ShadowDecoration.Parent = this.txtBrandId;
            this.txtBrandId.Size = new System.Drawing.Size(194, 30);
            this.txtBrandId.TabIndex = 55;
            // 
            // txtBrandDisc
            // 
            this.txtBrandDisc.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBrandDisc.DefaultText = "";
            this.txtBrandDisc.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtBrandDisc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtBrandDisc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtBrandDisc.DisabledState.Parent = this.txtBrandDisc;
            this.txtBrandDisc.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtBrandDisc.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtBrandDisc.FocusedState.Parent = this.txtBrandDisc;
            this.txtBrandDisc.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBrandDisc.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtBrandDisc.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtBrandDisc.HoverState.Parent = this.txtBrandDisc;
            this.txtBrandDisc.Location = new System.Drawing.Point(3, 260);
            this.txtBrandDisc.Multiline = true;
            this.txtBrandDisc.Name = "txtBrandDisc";
            this.txtBrandDisc.PasswordChar = '\0';
            this.txtBrandDisc.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtBrandDisc.PlaceholderText = "Ex: Products Details (Max 50 words)";
            this.txtBrandDisc.SelectedText = "";
            this.txtBrandDisc.ShadowDecoration.Parent = this.txtBrandDisc;
            this.txtBrandDisc.Size = new System.Drawing.Size(194, 115);
            this.txtBrandDisc.TabIndex = 146;
            // 
            // txtBrandName
            // 
            this.txtBrandName.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.txtBrandName.BackColor = System.Drawing.Color.Transparent;
            this.txtBrandName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBrandName.DefaultText = "";
            this.txtBrandName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtBrandName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtBrandName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtBrandName.DisabledState.Parent = this.txtBrandName;
            this.txtBrandName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtBrandName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtBrandName.FocusedState.Parent = this.txtBrandName;
            this.txtBrandName.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBrandName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtBrandName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtBrandName.HoverState.Parent = this.txtBrandName;
            this.txtBrandName.Location = new System.Drawing.Point(3, 113);
            this.txtBrandName.Name = "txtBrandName";
            this.txtBrandName.PasswordChar = '\0';
            this.txtBrandName.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.txtBrandName.PlaceholderText = "Brand:  Coca cola, Lays";
            this.txtBrandName.SelectedText = "";
            this.txtBrandName.ShadowDecoration.Parent = this.txtBrandName;
            this.txtBrandName.Size = new System.Drawing.Size(194, 30);
            this.txtBrandName.TabIndex = 56;
            // 
            // btnRemoveProductPhoto
            // 
            this.btnRemoveProductPhoto.Animated = true;
            this.btnRemoveProductPhoto.CheckedState.Parent = this.btnRemoveProductPhoto;
            this.btnRemoveProductPhoto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRemoveProductPhoto.CustomImages.HoveredImage = global::FinalPoject.Properties.Resources.icons8_remove_image_480px;
            this.btnRemoveProductPhoto.CustomImages.Image = global::FinalPoject.Properties.Resources.icons8_remove_image_480px_1;
            this.btnRemoveProductPhoto.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnRemoveProductPhoto.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnRemoveProductPhoto.CustomImages.Parent = this.btnRemoveProductPhoto;
            this.btnRemoveProductPhoto.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(229)))));
            this.btnRemoveProductPhoto.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveProductPhoto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnRemoveProductPhoto.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnRemoveProductPhoto.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveProductPhoto.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnRemoveProductPhoto.HoverState.Parent = this.btnRemoveProductPhoto;
            this.btnRemoveProductPhoto.Location = new System.Drawing.Point(187, 142);
            this.btnRemoveProductPhoto.Name = "btnRemoveProductPhoto";
            this.btnRemoveProductPhoto.ShadowDecoration.Parent = this.btnRemoveProductPhoto;
            this.btnRemoveProductPhoto.Size = new System.Drawing.Size(190, 37);
            this.btnRemoveProductPhoto.TabIndex = 133;
            this.btnRemoveProductPhoto.Text = "Remove";
            this.btnRemoveProductPhoto.TextOffset = new System.Drawing.Point(12, 0);
            // 
            // btnAddProductPhoto
            // 
            this.btnAddProductPhoto.Animated = true;
            this.btnAddProductPhoto.CheckedState.Parent = this.btnAddProductPhoto;
            this.btnAddProductPhoto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddProductPhoto.CustomImages.HoveredImage = global::FinalPoject.Properties.Resources.icons8_edit_image_480px;
            this.btnAddProductPhoto.CustomImages.Image = global::FinalPoject.Properties.Resources.icons8_edit_image_480px_1;
            this.btnAddProductPhoto.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnAddProductPhoto.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnAddProductPhoto.CustomImages.Parent = this.btnAddProductPhoto;
            this.btnAddProductPhoto.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(255)))), ((int)(((byte)(203)))));
            this.btnAddProductPhoto.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProductPhoto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(173)))), ((int)(((byte)(27)))));
            this.btnAddProductPhoto.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(173)))), ((int)(((byte)(27)))));
            this.btnAddProductPhoto.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProductPhoto.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnAddProductPhoto.HoverState.Parent = this.btnAddProductPhoto;
            this.btnAddProductPhoto.Location = new System.Drawing.Point(187, 95);
            this.btnAddProductPhoto.Name = "btnAddProductPhoto";
            this.btnAddProductPhoto.ShadowDecoration.Parent = this.btnAddProductPhoto;
            this.btnAddProductPhoto.Size = new System.Drawing.Size(190, 37);
            this.btnAddProductPhoto.TabIndex = 132;
            this.btnAddProductPhoto.Text = "Add";
            this.btnAddProductPhoto.TextOffset = new System.Drawing.Point(8, 0);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(67, 258);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 15);
            this.label8.TabIndex = 44;
            this.label8.Text = "Brand ID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(46, 357);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 15);
            this.label7.TabIndex = 45;
            this.label7.Text = "Brand Name";
            // 
            // pbmage
            // 
            this.pbmage.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pbmage.ErrorImage = global::FinalPoject.Properties.Resources.icons8_no_image_480px_2;
            this.pbmage.Image = global::FinalPoject.Properties.Resources.icons8_add_camera_480px;
            this.pbmage.Location = new System.Drawing.Point(20, 20);
            this.pbmage.Margin = new System.Windows.Forms.Padding(2);
            this.pbmage.Name = "pbmage";
            this.pbmage.ShadowDecoration.Parent = this.pbmage;
            this.pbmage.Size = new System.Drawing.Size(150, 162);
            this.pbmage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbmage.TabIndex = 148;
            this.pbmage.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(183, 24);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 20);
            this.label9.TabIndex = 147;
            this.label9.Text = "File Name";
            // 
            // guna2TextBox11
            // 
            this.guna2TextBox11.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox11.DefaultText = "";
            this.guna2TextBox11.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox11.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox11.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox11.DisabledState.Parent = this.guna2TextBox11;
            this.guna2TextBox11.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox11.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox11.FocusedState.Parent = this.guna2TextBox11;
            this.guna2TextBox11.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2TextBox11.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox11.HoverState.Parent = this.guna2TextBox11;
            this.guna2TextBox11.Location = new System.Drawing.Point(187, 49);
            this.guna2TextBox11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.guna2TextBox11.Name = "guna2TextBox11";
            this.guna2TextBox11.PasswordChar = '\0';
            this.guna2TextBox11.PlaceholderText = "filename.jpg/png";
            this.guna2TextBox11.SelectedText = "";
            this.guna2TextBox11.ShadowDecoration.Parent = this.guna2TextBox11;
            this.guna2TextBox11.Size = new System.Drawing.Size(190, 32);
            this.guna2TextBox11.TabIndex = 146;
            // 
            // guna2Panel10
            // 
            this.guna2Panel10.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel10.Location = new System.Drawing.Point(0, 550);
            this.guna2Panel10.Name = "guna2Panel10";
            this.guna2Panel10.ShadowDecoration.Parent = this.guna2Panel10;
            this.guna2Panel10.Size = new System.Drawing.Size(414, 13);
            this.guna2Panel10.TabIndex = 142;
            // 
            // guna2Panel20
            // 
            this.guna2Panel20.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel20.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel20.Location = new System.Drawing.Point(0, 57);
            this.guna2Panel20.Name = "guna2Panel20";
            this.guna2Panel20.ShadowDecoration.Parent = this.guna2Panel20;
            this.guna2Panel20.Size = new System.Drawing.Size(414, 13);
            this.guna2Panel20.TabIndex = 139;
            // 
            // guna2Panel62
            // 
            this.guna2Panel62.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel62.Controls.Add(this.tableLayoutPanel3);
            this.guna2Panel62.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel62.CustomBorderThickness = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.guna2Panel62.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel62.Location = new System.Drawing.Point(0, 563);
            this.guna2Panel62.Name = "guna2Panel62";
            this.guna2Panel62.ShadowDecoration.Parent = this.guna2Panel62;
            this.guna2Panel62.Size = new System.Drawing.Size(414, 57);
            this.guna2Panel62.TabIndex = 132;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.btnCancle, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.btnSaveBrand, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(414, 57);
            this.tableLayoutPanel3.TabIndex = 135;
            // 
            // btnCancle
            // 
            this.btnCancle.Animated = true;
            this.btnCancle.CheckedState.Parent = this.btnCancle;
            this.btnCancle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancle.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnCancle.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnCancle.CustomImages.Parent = this.btnCancle;
            this.btnCancle.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnCancle.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(229)))));
            this.btnCancle.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnCancle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnCancle.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnCancle.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnCancle.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnCancle.HoverState.Parent = this.btnCancle;
            this.btnCancle.Location = new System.Drawing.Point(214, 11);
            this.btnCancle.Name = "btnCancle";
            this.btnCancle.ShadowDecoration.Parent = this.btnCancle;
            this.btnCancle.Size = new System.Drawing.Size(142, 35);
            this.btnCancle.TabIndex = 117;
            this.btnCancle.Text = "Cancel";
            this.btnCancle.Click += new System.EventHandler(this.btnCancle_Click);
            // 
            // btnSaveBrand
            // 
            this.btnSaveBrand.Animated = true;
            this.btnSaveBrand.CheckedState.Parent = this.btnSaveBrand;
            this.btnSaveBrand.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveBrand.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSaveBrand.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnSaveBrand.CustomImages.Parent = this.btnSaveBrand;
            this.btnSaveBrand.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSaveBrand.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.btnSaveBrand.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnSaveBrand.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(153)))), ((int)(((byte)(255)))));
            this.btnSaveBrand.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(153)))), ((int)(((byte)(255)))));
            this.btnSaveBrand.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnSaveBrand.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnSaveBrand.HoverState.Parent = this.btnSaveBrand;
            this.btnSaveBrand.Location = new System.Drawing.Point(58, 11);
            this.btnSaveBrand.Name = "btnSaveBrand";
            this.btnSaveBrand.ShadowDecoration.Parent = this.btnSaveBrand;
            this.btnSaveBrand.Size = new System.Drawing.Size(142, 35);
            this.btnSaveBrand.TabIndex = 118;
            this.btnSaveBrand.Text = "Save";
            this.btnSaveBrand.Click += new System.EventHandler(this.btnSaveBrand_Click);
            // 
            // guna2Panel15
            // 
            this.guna2Panel15.Controls.Add(this.guna2Panel16);
            this.guna2Panel15.Controls.Add(this.label5);
            this.guna2Panel15.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel15.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.guna2Panel15.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel15.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel15.Name = "guna2Panel15";
            this.guna2Panel15.ShadowDecoration.Parent = this.guna2Panel15;
            this.guna2Panel15.Size = new System.Drawing.Size(414, 57);
            this.guna2Panel15.TabIndex = 130;
            // 
            // guna2Panel16
            // 
            this.guna2Panel16.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel16.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel16.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel16.Name = "guna2Panel16";
            this.guna2Panel16.ShadowDecoration.Parent = this.guna2Panel16;
            this.guna2Panel16.Size = new System.Drawing.Size(20, 57);
            this.guna2Panel16.TabIndex = 19;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(26, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 21);
            this.label5.TabIndex = 0;
            this.label5.Text = "Add Barnd:";
            // 
            // guna2Panel11
            // 
            this.guna2Panel11.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel11.BorderColor = System.Drawing.Color.Silver;
            this.guna2Panel11.BorderRadius = 12;
            this.guna2Panel11.BorderThickness = 1;
            this.guna2Panel11.Controls.Add(this.dgvBrand);
            this.guna2Panel11.Controls.Add(this.guna2Panel28);
            this.guna2Panel11.Controls.Add(this.guna2Panel26);
            this.guna2Panel11.Controls.Add(this.guna2Panel18);
            this.guna2Panel11.Controls.Add(this.guna2Panel21);
            this.guna2Panel11.Controls.Add(this.guna2Panel13);
            this.guna2Panel11.Controls.Add(this.guna2Panel5);
            this.guna2Panel11.Controls.Add(this.guna2Panel17);
            this.guna2Panel11.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2Panel11.FillColor = System.Drawing.Color.White;
            this.guna2Panel11.Location = new System.Drawing.Point(3, 3);
            this.guna2Panel11.Name = "guna2Panel11";
            this.guna2Panel11.ShadowDecoration.Parent = this.guna2Panel11;
            this.guna2Panel11.Size = new System.Drawing.Size(773, 620);
            this.guna2Panel11.TabIndex = 27;
            // 
            // dgvBrand
            // 
            this.dgvBrand.AllowUserToAddRows = false;
            this.dgvBrand.AllowUserToDeleteRows = false;
            this.dgvBrand.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvBrand.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBrand.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.BrandId,
            this.BrandTag,
            this.BrandName,
            this.VendorName,
            this.BrandStatus,
            this.BrandDisc,
            this.VendorId});
            this.dgvBrand.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvBrand.Location = new System.Drawing.Point(8, 154);
            this.dgvBrand.Margin = new System.Windows.Forms.Padding(2);
            this.dgvBrand.Name = "dgvBrand";
            this.dgvBrand.ReadOnly = true;
            this.dgvBrand.RowHeadersWidth = 51;
            this.dgvBrand.RowTemplate.Height = 24;
            this.dgvBrand.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBrand.Size = new System.Drawing.Size(757, 401);
            this.dgvBrand.TabIndex = 162;
            this.dgvBrand.DoubleClick += new System.EventHandler(this.dgvBrand_DoubleClick);
            // 
            // BrandId
            // 
            this.BrandId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.BrandId.DataPropertyName = "BrandId";
            this.BrandId.HeaderText = "Brand ID";
            this.BrandId.MinimumWidth = 6;
            this.BrandId.Name = "BrandId";
            this.BrandId.ReadOnly = true;
            // 
            // BrandTag
            // 
            this.BrandTag.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.BrandTag.DataPropertyName = "BrandTag";
            this.BrandTag.HeaderText = "Brand TAG";
            this.BrandTag.MinimumWidth = 6;
            this.BrandTag.Name = "BrandTag";
            this.BrandTag.ReadOnly = true;
            // 
            // BrandName
            // 
            this.BrandName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.BrandName.DataPropertyName = "BrandName";
            this.BrandName.HeaderText = "Brand Name";
            this.BrandName.MinimumWidth = 6;
            this.BrandName.Name = "BrandName";
            this.BrandName.ReadOnly = true;
            // 
            // VendorName
            // 
            this.VendorName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.VendorName.DataPropertyName = "VendorName";
            this.VendorName.HeaderText = "Vendor Name";
            this.VendorName.Name = "VendorName";
            this.VendorName.ReadOnly = true;
            // 
            // BrandStatus
            // 
            this.BrandStatus.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.BrandStatus.DataPropertyName = "BrandStatus";
            this.BrandStatus.HeaderText = "Brand Status";
            this.BrandStatus.Name = "BrandStatus";
            this.BrandStatus.ReadOnly = true;
            // 
            // BrandDisc
            // 
            this.BrandDisc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.BrandDisc.DataPropertyName = "BrandDescription";
            this.BrandDisc.HeaderText = "Brand Disc.";
            this.BrandDisc.MinimumWidth = 6;
            this.BrandDisc.Name = "BrandDisc";
            this.BrandDisc.ReadOnly = true;
            // 
            // VendorId
            // 
            this.VendorId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.VendorId.DataPropertyName = "VendorId";
            this.VendorId.HeaderText = "Brand Picture";
            this.VendorId.MinimumWidth = 6;
            this.VendorId.Name = "VendorId";
            this.VendorId.ReadOnly = true;
            // 
            // guna2Panel28
            // 
            this.guna2Panel28.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel28.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel28.Location = new System.Drawing.Point(8, 555);
            this.guna2Panel28.Name = "guna2Panel28";
            this.guna2Panel28.ShadowDecoration.Parent = this.guna2Panel28;
            this.guna2Panel28.Size = new System.Drawing.Size(757, 8);
            this.guna2Panel28.TabIndex = 159;
            // 
            // guna2Panel26
            // 
            this.guna2Panel26.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel26.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel26.Location = new System.Drawing.Point(765, 154);
            this.guna2Panel26.Name = "guna2Panel26";
            this.guna2Panel26.ShadowDecoration.Parent = this.guna2Panel26;
            this.guna2Panel26.Size = new System.Drawing.Size(8, 409);
            this.guna2Panel26.TabIndex = 156;
            // 
            // guna2Panel18
            // 
            this.guna2Panel18.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel18.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel18.Location = new System.Drawing.Point(0, 154);
            this.guna2Panel18.Name = "guna2Panel18";
            this.guna2Panel18.ShadowDecoration.Parent = this.guna2Panel18;
            this.guna2Panel18.Size = new System.Drawing.Size(8, 409);
            this.guna2Panel18.TabIndex = 155;
            // 
            // guna2Panel21
            // 
            this.guna2Panel21.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel21.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel21.Location = new System.Drawing.Point(0, 146);
            this.guna2Panel21.Name = "guna2Panel21";
            this.guna2Panel21.ShadowDecoration.Parent = this.guna2Panel21;
            this.guna2Panel21.Size = new System.Drawing.Size(773, 8);
            this.guna2Panel21.TabIndex = 154;
            // 
            // guna2Panel13
            // 
            this.guna2Panel13.Controls.Add(this.tableLayoutPanel4);
            this.guna2Panel13.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel13.CustomBorderThickness = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.guna2Panel13.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel13.Location = new System.Drawing.Point(0, 563);
            this.guna2Panel13.Name = "guna2Panel13";
            this.guna2Panel13.ShadowDecoration.Parent = this.guna2Panel13;
            this.guna2Panel13.Size = new System.Drawing.Size(773, 57);
            this.guna2Panel13.TabIndex = 133;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 5;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 225F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 225F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.btnBrandRefresh, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.btnDeleteBrand, 3, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 3;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(773, 57);
            this.tableLayoutPanel4.TabIndex = 137;
            // 
            // btnBrandRefresh
            // 
            this.btnBrandRefresh.Animated = true;
            this.btnBrandRefresh.CheckedState.Parent = this.btnBrandRefresh;
            this.btnBrandRefresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBrandRefresh.CustomImages.HoveredImage = global::FinalPoject.Properties.Resources.icons8_restart_96px_1;
            this.btnBrandRefresh.CustomImages.Image = global::FinalPoject.Properties.Resources.icons8_restart_96px;
            this.btnBrandRefresh.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnBrandRefresh.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnBrandRefresh.CustomImages.Parent = this.btnBrandRefresh;
            this.btnBrandRefresh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnBrandRefresh.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(233)))), ((int)(((byte)(249)))));
            this.btnBrandRefresh.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrandRefresh.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(148)))), ((int)(((byte)(247)))));
            this.btnBrandRefresh.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(148)))), ((int)(((byte)(247)))));
            this.btnBrandRefresh.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrandRefresh.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(233)))), ((int)(((byte)(249)))));
            this.btnBrandRefresh.HoverState.Parent = this.btnBrandRefresh;
            this.btnBrandRefresh.Location = new System.Drawing.Point(160, 11);
            this.btnBrandRefresh.Name = "btnBrandRefresh";
            this.btnBrandRefresh.ShadowDecoration.Parent = this.btnBrandRefresh;
            this.btnBrandRefresh.Size = new System.Drawing.Size(219, 35);
            this.btnBrandRefresh.TabIndex = 133;
            this.btnBrandRefresh.Text = "Refresh";
            this.btnBrandRefresh.TextOffset = new System.Drawing.Point(8, 0);
            this.btnBrandRefresh.Click += new System.EventHandler(this.btnBrandRefresh_Click);
            // 
            // btnDeleteBrand
            // 
            this.btnDeleteBrand.Animated = true;
            this.btnDeleteBrand.CheckedState.Parent = this.btnDeleteBrand;
            this.btnDeleteBrand.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeleteBrand.CustomImages.HoveredImage = global::FinalPoject.Properties.Resources.icons8_trash_can_480px;
            this.btnDeleteBrand.CustomImages.Image = global::FinalPoject.Properties.Resources.icons8_trash_can_480px_1;
            this.btnDeleteBrand.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnDeleteBrand.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnDeleteBrand.CustomImages.Parent = this.btnDeleteBrand;
            this.btnDeleteBrand.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDeleteBrand.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(229)))));
            this.btnDeleteBrand.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnDeleteBrand.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnDeleteBrand.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnDeleteBrand.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnDeleteBrand.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnDeleteBrand.HoverState.Parent = this.btnDeleteBrand;
            this.btnDeleteBrand.Location = new System.Drawing.Point(393, 11);
            this.btnDeleteBrand.Name = "btnDeleteBrand";
            this.btnDeleteBrand.ShadowDecoration.Parent = this.btnDeleteBrand;
            this.btnDeleteBrand.Size = new System.Drawing.Size(219, 35);
            this.btnDeleteBrand.TabIndex = 135;
            this.btnDeleteBrand.Text = "Delete";
            this.btnDeleteBrand.Click += new System.EventHandler(this.btnDeleteBrand_Click);
            // 
            // guna2Panel5
            // 
            this.guna2Panel5.Controls.Add(this.guna2Panel22);
            this.guna2Panel5.Controls.Add(this.guna2Panel27);
            this.guna2Panel5.Controls.Add(this.guna2Panel14);
            this.guna2Panel5.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel5.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.guna2Panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel5.Location = new System.Drawing.Point(0, 57);
            this.guna2Panel5.Name = "guna2Panel5";
            this.guna2Panel5.ShadowDecoration.Parent = this.guna2Panel5;
            this.guna2Panel5.Size = new System.Drawing.Size(773, 89);
            this.guna2Panel5.TabIndex = 132;
            // 
            // guna2Panel22
            // 
            this.guna2Panel22.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel22.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel22.Location = new System.Drawing.Point(20, 81);
            this.guna2Panel22.Name = "guna2Panel22";
            this.guna2Panel22.ShadowDecoration.Parent = this.guna2Panel22;
            this.guna2Panel22.Size = new System.Drawing.Size(733, 8);
            this.guna2Panel22.TabIndex = 182;
            // 
            // guna2Panel27
            // 
            this.guna2Panel27.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel27.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel27.Location = new System.Drawing.Point(753, 0);
            this.guna2Panel27.Name = "guna2Panel27";
            this.guna2Panel27.ShadowDecoration.Parent = this.guna2Panel27;
            this.guna2Panel27.Size = new System.Drawing.Size(20, 89);
            this.guna2Panel27.TabIndex = 20;
            // 
            // guna2Panel14
            // 
            this.guna2Panel14.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel14.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel14.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel14.Name = "guna2Panel14";
            this.guna2Panel14.ShadowDecoration.Parent = this.guna2Panel14;
            this.guna2Panel14.Size = new System.Drawing.Size(20, 89);
            this.guna2Panel14.TabIndex = 19;
            // 
            // guna2Panel17
            // 
            this.guna2Panel17.Controls.Add(this.guna2Panel23);
            this.guna2Panel17.Controls.Add(this.guna2Panel25);
            this.guna2Panel17.Controls.Add(this.label6);
            this.guna2Panel17.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel17.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.guna2Panel17.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel17.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel17.Name = "guna2Panel17";
            this.guna2Panel17.ShadowDecoration.Parent = this.guna2Panel17;
            this.guna2Panel17.Size = new System.Drawing.Size(773, 57);
            this.guna2Panel17.TabIndex = 131;
            // 
            // guna2Panel23
            // 
            this.guna2Panel23.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel23.Controls.Add(this.label24);
            this.guna2Panel23.Controls.Add(this.txtSearchBrand);
            this.guna2Panel23.Controls.Add(this.guna2Panel24);
            this.guna2Panel23.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel23.Location = new System.Drawing.Point(271, 0);
            this.guna2Panel23.Name = "guna2Panel23";
            this.guna2Panel23.ShadowDecoration.Parent = this.guna2Panel23;
            this.guna2Panel23.Size = new System.Drawing.Size(502, 57);
            this.guna2Panel23.TabIndex = 21;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.label24.Location = new System.Drawing.Point(138, 19);
            this.label24.Margin = new System.Windows.Forms.Padding(0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(95, 19);
            this.label24.TabIndex = 166;
            this.label24.Text = "Search Brands";
            // 
            // txtSearchBrand
            // 
            this.txtSearchBrand.AccessibleRole = System.Windows.Forms.AccessibleRole.Grip;
            this.txtSearchBrand.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSearchBrand.DefaultText = "";
            this.txtSearchBrand.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtSearchBrand.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtSearchBrand.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSearchBrand.DisabledState.Parent = this.txtSearchBrand;
            this.txtSearchBrand.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSearchBrand.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSearchBrand.FocusedState.Parent = this.txtSearchBrand;
            this.txtSearchBrand.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchBrand.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSearchBrand.HoverState.Parent = this.txtSearchBrand;
            this.txtSearchBrand.HoverState.PlaceholderForeColor = System.Drawing.Color.Transparent;
            this.txtSearchBrand.IconRight = global::FinalPoject.Properties.Resources.icons8_search_480px;
            this.txtSearchBrand.Location = new System.Drawing.Point(237, 13);
            this.txtSearchBrand.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtSearchBrand.Name = "txtSearchBrand";
            this.txtSearchBrand.PasswordChar = '\0';
            this.txtSearchBrand.PlaceholderText = "by Name, Tag, Cate. Brand";
            this.txtSearchBrand.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtSearchBrand.SelectedText = "";
            this.txtSearchBrand.ShadowDecoration.Parent = this.txtSearchBrand;
            this.txtSearchBrand.Size = new System.Drawing.Size(245, 30);
            this.txtSearchBrand.TabIndex = 165;
            this.txtSearchBrand.TextChanged += new System.EventHandler(this.txtSearchBrand_TextChanged);
            // 
            // guna2Panel24
            // 
            this.guna2Panel24.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel24.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel24.Location = new System.Drawing.Point(482, 0);
            this.guna2Panel24.Name = "guna2Panel24";
            this.guna2Panel24.ShadowDecoration.Parent = this.guna2Panel24;
            this.guna2Panel24.Size = new System.Drawing.Size(20, 57);
            this.guna2Panel24.TabIndex = 135;
            // 
            // guna2Panel25
            // 
            this.guna2Panel25.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel25.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel25.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel25.Name = "guna2Panel25";
            this.guna2Panel25.ShadowDecoration.Parent = this.guna2Panel25;
            this.guna2Panel25.Size = new System.Drawing.Size(20, 57);
            this.guna2Panel25.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(26, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 21);
            this.label6.TabIndex = 0;
            this.label6.Text = "View All Brands";
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel1.Location = new System.Drawing.Point(15, 89);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(1214, 16);
            this.guna2Panel1.TabIndex = 41;
            // 
            // pnlOrderSelect
            // 
            this.pnlOrderSelect.BackColor = System.Drawing.Color.Transparent;
            this.pnlOrderSelect.BorderColor = System.Drawing.Color.Silver;
            this.pnlOrderSelect.BorderRadius = 12;
            this.pnlOrderSelect.BorderThickness = 1;
            this.pnlOrderSelect.Controls.Add(this.guna2Panel2);
            this.pnlOrderSelect.Controls.Add(this.guna2Panel6);
            this.pnlOrderSelect.CustomBorderColor = System.Drawing.Color.Silver;
            this.pnlOrderSelect.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlOrderSelect.FillColor = System.Drawing.Color.White;
            this.pnlOrderSelect.Location = new System.Drawing.Point(15, 16);
            this.pnlOrderSelect.Name = "pnlOrderSelect";
            this.pnlOrderSelect.ShadowDecoration.Parent = this.pnlOrderSelect;
            this.pnlOrderSelect.Size = new System.Drawing.Size(1214, 73);
            this.pnlOrderSelect.TabIndex = 40;
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.guna2Panel8);
            this.guna2Panel2.Controls.Add(this.guna2Panel7);
            this.guna2Panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel2.Location = new System.Drawing.Point(904, 0);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.ShadowDecoration.Parent = this.guna2Panel2;
            this.guna2Panel2.Size = new System.Drawing.Size(310, 73);
            this.guna2Panel2.TabIndex = 6;
            // 
            // guna2Panel8
            // 
            this.guna2Panel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel8.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel8.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel8.Name = "guna2Panel8";
            this.guna2Panel8.ShadowDecoration.Parent = this.guna2Panel8;
            this.guna2Panel8.Size = new System.Drawing.Size(20, 73);
            this.guna2Panel8.TabIndex = 18;
            // 
            // guna2Panel7
            // 
            this.guna2Panel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel7.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel7.Location = new System.Drawing.Point(290, 0);
            this.guna2Panel7.Name = "guna2Panel7";
            this.guna2Panel7.ShadowDecoration.Parent = this.guna2Panel7;
            this.guna2Panel7.Size = new System.Drawing.Size(20, 73);
            this.guna2Panel7.TabIndex = 17;
            // 
            // guna2Panel6
            // 
            this.guna2Panel6.Controls.Add(this.label3);
            this.guna2Panel6.Controls.Add(this.guna2Panel9);
            this.guna2Panel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel6.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel6.Name = "guna2Panel6";
            this.guna2Panel6.ShadowDecoration.Parent = this.guna2Panel6;
            this.guna2Panel6.Size = new System.Drawing.Size(542, 73);
            this.guna2Panel6.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(18, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 39);
            this.label3.TabIndex = 20;
            this.label3.Text = "Brands";
            // 
            // guna2Panel9
            // 
            this.guna2Panel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel9.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel9.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel9.Name = "guna2Panel9";
            this.guna2Panel9.ShadowDecoration.Parent = this.guna2Panel9;
            this.guna2Panel9.Size = new System.Drawing.Size(20, 73);
            this.guna2Panel9.TabIndex = 19;
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel3.Location = new System.Drawing.Point(1229, 16);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.ShadowDecoration.Parent = this.guna2Panel3;
            this.guna2Panel3.Size = new System.Drawing.Size(15, 715);
            this.guna2Panel3.TabIndex = 39;
            // 
            // pnlInsideLeft
            // 
            this.pnlInsideLeft.BackColor = System.Drawing.Color.Transparent;
            this.pnlInsideLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlInsideLeft.Location = new System.Drawing.Point(0, 16);
            this.pnlInsideLeft.Name = "pnlInsideLeft";
            this.pnlInsideLeft.ShadowDecoration.Parent = this.pnlInsideLeft;
            this.pnlInsideLeft.Size = new System.Drawing.Size(15, 715);
            this.pnlInsideLeft.TabIndex = 38;
            // 
            // pnlBottom
            // 
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 731);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.ShadowDecoration.Parent = this.pnlBottom;
            this.pnlBottom.Size = new System.Drawing.Size(1244, 16);
            this.pnlBottom.TabIndex = 37;
            // 
            // pnlInsideTop
            // 
            this.pnlInsideTop.BackColor = System.Drawing.Color.Transparent;
            this.pnlInsideTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlInsideTop.Location = new System.Drawing.Point(0, 0);
            this.pnlInsideTop.Name = "pnlInsideTop";
            this.pnlInsideTop.ShadowDecoration.Parent = this.pnlInsideTop;
            this.pnlInsideTop.Size = new System.Drawing.Size(1244, 16);
            this.pnlInsideTop.TabIndex = 36;
            // 
            // FormBrand
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1244, 747);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.guna2Panel1);
            this.Controls.Add(this.pnlOrderSelect);
            this.Controls.Add(this.guna2Panel3);
            this.Controls.Add(this.pnlInsideLeft);
            this.Controls.Add(this.pnlBottom);
            this.Controls.Add(this.pnlInsideTop);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1260, 786);
            this.Name = "FormBrand";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormBrand";
            this.Load += new System.EventHandler(this.FormBrand_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.guna2Panel12.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbmage)).EndInit();
            this.guna2Panel62.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.guna2Panel15.ResumeLayout(false);
            this.guna2Panel15.PerformLayout();
            this.guna2Panel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBrand)).EndInit();
            this.guna2Panel13.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.guna2Panel5.ResumeLayout(false);
            this.guna2Panel17.ResumeLayout(false);
            this.guna2Panel17.PerformLayout();
            this.guna2Panel23.ResumeLayout(false);
            this.guna2Panel23.PerformLayout();
            this.pnlOrderSelect.ResumeLayout(false);
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel6.ResumeLayout(false);
            this.guna2Panel6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel12;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel10;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel20;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel62;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private Guna.UI2.WinForms.Guna2Button btnCancle;
        private Guna.UI2.WinForms.Guna2Button btnSaveBrand;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel15;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel16;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel11;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel28;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel26;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel18;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel21;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private Guna.UI2.WinForms.Guna2Button btnBrandRefresh;
        private Guna.UI2.WinForms.Guna2Button btnDeleteBrand;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel22;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel27;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel14;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel17;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel23;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel24;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel25;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2Panel pnlOrderSelect;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel8;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel7;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel6;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel9;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2Panel pnlInsideLeft;
        private Guna.UI2.WinForms.Guna2Panel pnlBottom;
        private Guna.UI2.WinForms.Guna2Panel pnlInsideTop;
        private System.Windows.Forms.DataGridView dgvBrand;
        private System.Windows.Forms.Label label24;
        private Guna.UI2.WinForms.Guna2TextBox txtSearchBrand;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private Guna.UI2.WinForms.Guna2TextBox txtBrandStatus;
        private Guna.UI2.WinForms.Guna2ComboBox cmbVendor;
        private Guna.UI2.WinForms.Guna2TextBox txtBrandTag;
        private Guna.UI2.WinForms.Guna2TextBox txtBrandId;
        private Guna.UI2.WinForms.Guna2TextBox txtBrandDisc;
        private Guna.UI2.WinForms.Guna2TextBox txtBrandName;
        private Guna.UI2.WinForms.Guna2Button btnRemoveProductPhoto;
        private Guna.UI2.WinForms.Guna2Button btnAddProductPhoto;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2PictureBox pbmage;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox11;
        private Guna.UI2.WinForms.Guna2Button btnAddVendors;
        private System.Windows.Forms.DataGridViewTextBoxColumn BrandId;
        private System.Windows.Forms.DataGridViewTextBoxColumn BrandTag;
        private System.Windows.Forms.DataGridViewTextBoxColumn BrandName;
        private System.Windows.Forms.DataGridViewTextBoxColumn VendorName;
        private System.Windows.Forms.DataGridViewTextBoxColumn BrandStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn BrandDisc;
        private System.Windows.Forms.DataGridViewTextBoxColumn VendorId;
    }
}