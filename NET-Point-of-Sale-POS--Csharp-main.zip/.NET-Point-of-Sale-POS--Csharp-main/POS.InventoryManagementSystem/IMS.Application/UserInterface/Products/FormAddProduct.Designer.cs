﻿
namespace FinalPoject
{
    partial class FormAddProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlInsideTop = new Guna.UI2.WinForms.Guna2Panel();
            this.pnlBottom = new Guna.UI2.WinForms.Guna2Panel();
            this.pnlInsideLeft = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel4 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.guna2Panel12 = new Guna.UI2.WinForms.Guna2Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAddBarnd = new Guna.UI2.WinForms.Guna2Button();
            this.label26 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.txtTag = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtUniStock = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtDiscountRate = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtId = new Guna.UI2.WinForms.Guna2TextBox();
            this.cmbBrand = new Guna.UI2.WinForms.Guna2ComboBox();
            this.txtDiscription = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtQuantityPerUnit = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtPerUnitPrice = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtWeight = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtMSRP = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtSize = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtColor = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtName = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtStatus = new Guna.UI2.WinForms.Guna2TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnRemoveProductPhoto = new Guna.UI2.WinForms.Guna2Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btnAddProductPhoto = new Guna.UI2.WinForms.Guna2Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pbImage = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2TextBox11 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Panel10 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel20 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel62 = new Guna.UI2.WinForms.Guna2Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.btnCancle = new Guna.UI2.WinForms.Guna2Button();
            this.btnSaveProduct = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel15 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel16 = new Guna.UI2.WinForms.Guna2Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2Panel11 = new Guna.UI2.WinForms.Guna2Panel();
            this.dgvAllProduct = new System.Windows.Forms.DataGridView();
            this.pID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pTag = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pBrandName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pMSRP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pPerUnPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pQuaPerUn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pDisRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pUnStock = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pColor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pWeight = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pDisc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.guna2Panel22 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel21 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel19 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel18 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel13 = new Guna.UI2.WinForms.Guna2Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.btnRefresh = new Guna.UI2.WinForms.Guna2Button();
            this.btnDeleteProduct = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel7 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel8 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel14 = new Guna.UI2.WinForms.Guna2Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.guna2Panel17 = new Guna.UI2.WinForms.Guna2Panel();
            this.txtSearchProduct = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Panel5 = new Guna.UI2.WinForms.Guna2Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.pnlOrderSelect = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel6 = new Guna.UI2.WinForms.Guna2Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2Panel9 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.guna2ElipseAddProducts = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.guna2Panel12.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).BeginInit();
            this.guna2Panel62.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.guna2Panel15.SuspendLayout();
            this.guna2Panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAllProduct)).BeginInit();
            this.guna2Panel13.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.guna2Panel7.SuspendLayout();
            this.guna2Panel2.SuspendLayout();
            this.guna2Panel14.SuspendLayout();
            this.pnlOrderSelect.SuspendLayout();
            this.guna2Panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlInsideTop
            // 
            this.pnlInsideTop.BackColor = System.Drawing.Color.Transparent;
            this.pnlInsideTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlInsideTop.Location = new System.Drawing.Point(0, 0);
            this.pnlInsideTop.Name = "pnlInsideTop";
            this.pnlInsideTop.ShadowDecoration.Parent = this.pnlInsideTop;
            this.pnlInsideTop.Size = new System.Drawing.Size(1244, 16);
            this.pnlInsideTop.TabIndex = 5;
            // 
            // pnlBottom
            // 
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 731);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.ShadowDecoration.Parent = this.pnlBottom;
            this.pnlBottom.Size = new System.Drawing.Size(1244, 16);
            this.pnlBottom.TabIndex = 9;
            // 
            // pnlInsideLeft
            // 
            this.pnlInsideLeft.BackColor = System.Drawing.Color.Transparent;
            this.pnlInsideLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlInsideLeft.Location = new System.Drawing.Point(0, 16);
            this.pnlInsideLeft.Name = "pnlInsideLeft";
            this.pnlInsideLeft.ShadowDecoration.Parent = this.pnlInsideLeft;
            this.pnlInsideLeft.Size = new System.Drawing.Size(15, 715);
            this.pnlInsideLeft.TabIndex = 12;
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel3.Location = new System.Drawing.Point(1229, 16);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.ShadowDecoration.Parent = this.guna2Panel3;
            this.guna2Panel3.Size = new System.Drawing.Size(15, 715);
            this.guna2Panel3.TabIndex = 16;
            // 
            // guna2Panel4
            // 
            this.guna2Panel4.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel4.Location = new System.Drawing.Point(15, 89);
            this.guna2Panel4.Name = "guna2Panel4";
            this.guna2Panel4.ShadowDecoration.Parent = this.guna2Panel4;
            this.guna2Panel4.Size = new System.Drawing.Size(1214, 16);
            this.guna2Panel4.TabIndex = 22;
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Controls.Add(this.tableLayoutPanel1);
            this.guna2Panel1.Controls.Add(this.guna2Panel4);
            this.guna2Panel1.Controls.Add(this.pnlOrderSelect);
            this.guna2Panel1.Controls.Add(this.guna2Panel3);
            this.guna2Panel1.Controls.Add(this.pnlInsideLeft);
            this.guna2Panel1.Controls.Add(this.pnlBottom);
            this.guna2Panel1.Controls.Add(this.pnlInsideTop);
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(1244, 747);
            this.guna2Panel1.TabIndex = 6;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 420F));
            this.tableLayoutPanel1.Controls.Add(this.guna2Panel12, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2Panel11, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(15, 105);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1214, 626);
            this.tableLayoutPanel1.TabIndex = 24;
            // 
            // guna2Panel12
            // 
            this.guna2Panel12.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel12.BorderColor = System.Drawing.Color.Silver;
            this.guna2Panel12.BorderRadius = 12;
            this.guna2Panel12.BorderThickness = 1;
            this.guna2Panel12.Controls.Add(this.panel1);
            this.guna2Panel12.Controls.Add(this.guna2Panel10);
            this.guna2Panel12.Controls.Add(this.guna2Panel20);
            this.guna2Panel12.Controls.Add(this.guna2Panel62);
            this.guna2Panel12.Controls.Add(this.guna2Panel15);
            this.guna2Panel12.CustomBorderColor = System.Drawing.Color.Transparent;
            this.guna2Panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2Panel12.FillColor = System.Drawing.Color.White;
            this.guna2Panel12.Location = new System.Drawing.Point(797, 3);
            this.guna2Panel12.Name = "guna2Panel12";
            this.guna2Panel12.ShadowDecoration.Parent = this.guna2Panel12;
            this.guna2Panel12.Size = new System.Drawing.Size(414, 620);
            this.guna2Panel12.TabIndex = 25;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.btnAddBarnd);
            this.panel1.Controls.Add(this.label26);
            this.panel1.Controls.Add(this.tableLayoutPanel2);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.btnRemoveProductPhoto);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.btnAddProductPhoto);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.pbImage);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.guna2TextBox11);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 70);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(414, 480);
            this.panel1.TabIndex = 152;
            // 
            // btnAddBarnd
            // 
            this.btnAddBarnd.Animated = true;
            this.btnAddBarnd.CheckedState.Parent = this.btnAddBarnd;
            this.btnAddBarnd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddBarnd.CustomImages.HoveredImage = global::FinalPoject.Properties.Resources.icons8_plus_math_480px_1;
            this.btnAddBarnd.CustomImages.Image = global::FinalPoject.Properties.Resources.icons8_plus_math_480px;
            this.btnAddBarnd.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnAddBarnd.CustomImages.Parent = this.btnAddBarnd;
            this.btnAddBarnd.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(255)))), ((int)(((byte)(203)))));
            this.btnAddBarnd.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddBarnd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(173)))), ((int)(((byte)(27)))));
            this.btnAddBarnd.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(173)))), ((int)(((byte)(27)))));
            this.btnAddBarnd.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddBarnd.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnAddBarnd.HoverState.Parent = this.btnAddBarnd;
            this.btnAddBarnd.Location = new System.Drawing.Point(337, 404);
            this.btnAddBarnd.Name = "btnAddBarnd";
            this.btnAddBarnd.ShadowDecoration.Parent = this.btnAddBarnd;
            this.btnAddBarnd.Size = new System.Drawing.Size(35, 30);
            this.btnAddBarnd.TabIndex = 203;
            this.btnAddBarnd.TextOffset = new System.Drawing.Point(8, 0);
            this.btnAddBarnd.Click += new System.EventHandler(this.btnAddBarnd_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(43, 311);
            this.label26.Margin = new System.Windows.Forms.Padding(0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(73, 15);
            this.label26.TabIndex = 165;
            this.label26.Text = "Product TAG";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.txtTag, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.txtUniStock, 0, 21);
            this.tableLayoutPanel2.Controls.Add(this.txtDiscountRate, 0, 23);
            this.tableLayoutPanel2.Controls.Add(this.txtId, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.cmbBrand, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.txtDiscription, 0, 27);
            this.tableLayoutPanel2.Controls.Add(this.txtQuantityPerUnit, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.txtPerUnitPrice, 0, 11);
            this.tableLayoutPanel2.Controls.Add(this.txtWeight, 0, 19);
            this.tableLayoutPanel2.Controls.Add(this.txtMSRP, 0, 13);
            this.tableLayoutPanel2.Controls.Add(this.txtSize, 0, 15);
            this.tableLayoutPanel2.Controls.Add(this.txtColor, 0, 17);
            this.tableLayoutPanel2.Controls.Add(this.txtName, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.txtStatus, 0, 25);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(132, 237);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 29;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 122F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(200, 852);
            this.tableLayoutPanel2.TabIndex = 164;
            // 
            // txtTag
            // 
            this.txtTag.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTag.DefaultText = "";
            this.txtTag.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtTag.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtTag.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTag.DisabledState.Parent = this.txtTag;
            this.txtTag.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTag.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTag.FocusedState.Parent = this.txtTag;
            this.txtTag.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTag.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtTag.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTag.HoverState.Parent = this.txtTag;
            this.txtTag.Location = new System.Drawing.Point(3, 64);
            this.txtTag.Name = "txtTag";
            this.txtTag.PasswordChar = '\0';
            this.txtTag.PlaceholderText = "Auto Generate";
            this.txtTag.ReadOnly = true;
            this.txtTag.SelectedText = "";
            this.txtTag.ShadowDecoration.Parent = this.txtTag;
            this.txtTag.Size = new System.Drawing.Size(194, 30);
            this.txtTag.TabIndex = 167;
            // 
            // txtUniStock
            // 
            this.txtUniStock.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtUniStock.DefaultText = "";
            this.txtUniStock.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtUniStock.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtUniStock.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtUniStock.DisabledState.Parent = this.txtUniStock;
            this.txtUniStock.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtUniStock.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtUniStock.FocusedState.Parent = this.txtUniStock;
            this.txtUniStock.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUniStock.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtUniStock.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtUniStock.HoverState.Parent = this.txtUniStock;
            this.txtUniStock.Location = new System.Drawing.Point(3, 505);
            this.txtUniStock.Name = "txtUniStock";
            this.txtUniStock.PasswordChar = '\0';
            this.txtUniStock.PlaceholderText = "Ex: 50";
            this.txtUniStock.SelectedText = "";
            this.txtUniStock.ShadowDecoration.Parent = this.txtUniStock;
            this.txtUniStock.Size = new System.Drawing.Size(194, 30);
            this.txtUniStock.TabIndex = 165;
            // 
            // txtDiscountRate
            // 
            this.txtDiscountRate.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDiscountRate.DefaultText = "";
            this.txtDiscountRate.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtDiscountRate.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtDiscountRate.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDiscountRate.DisabledState.Parent = this.txtDiscountRate;
            this.txtDiscountRate.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDiscountRate.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDiscountRate.FocusedState.Parent = this.txtDiscountRate;
            this.txtDiscountRate.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiscountRate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtDiscountRate.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDiscountRate.HoverState.Parent = this.txtDiscountRate;
            this.txtDiscountRate.Location = new System.Drawing.Point(3, 554);
            this.txtDiscountRate.Name = "txtDiscountRate";
            this.txtDiscountRate.PasswordChar = '\0';
            this.txtDiscountRate.PlaceholderText = "Ex: 20";
            this.txtDiscountRate.SelectedText = "";
            this.txtDiscountRate.ShadowDecoration.Parent = this.txtDiscountRate;
            this.txtDiscountRate.Size = new System.Drawing.Size(194, 30);
            this.txtDiscountRate.TabIndex = 145;
            // 
            // txtId
            // 
            this.txtId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtId.DefaultText = "";
            this.txtId.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtId.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtId.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtId.DisabledState.Parent = this.txtId;
            this.txtId.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtId.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtId.FocusedState.Parent = this.txtId;
            this.txtId.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtId.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtId.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtId.HoverState.Parent = this.txtId;
            this.txtId.Location = new System.Drawing.Point(3, 15);
            this.txtId.Name = "txtId";
            this.txtId.PasswordChar = '\0';
            this.txtId.PlaceholderText = "Auto Generate";
            this.txtId.SelectedText = "";
            this.txtId.ShadowDecoration.Parent = this.txtId;
            this.txtId.Size = new System.Drawing.Size(194, 30);
            this.txtId.TabIndex = 55;
            // 
            // cmbBrand
            // 
            this.cmbBrand.BackColor = System.Drawing.Color.Transparent;
            this.cmbBrand.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbBrand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBrand.FocusedColor = System.Drawing.Color.Empty;
            this.cmbBrand.FocusedState.Parent = this.cmbBrand;
            this.cmbBrand.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBrand.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbBrand.FormattingEnabled = true;
            this.cmbBrand.HoverState.Parent = this.cmbBrand;
            this.cmbBrand.ItemHeight = 30;
            this.cmbBrand.Items.AddRange(new object[] {
            "Set As Later"});
            this.cmbBrand.ItemsAppearance.Parent = this.cmbBrand;
            this.cmbBrand.Location = new System.Drawing.Point(2, 161);
            this.cmbBrand.Margin = new System.Windows.Forms.Padding(2);
            this.cmbBrand.Name = "cmbBrand";
            this.cmbBrand.ShadowDecoration.Parent = this.cmbBrand;
            this.cmbBrand.Size = new System.Drawing.Size(196, 36);
            this.cmbBrand.TabIndex = 133;
            // 
            // txtDiscription
            // 
            this.txtDiscription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDiscription.DefaultText = "";
            this.txtDiscription.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtDiscription.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtDiscription.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDiscription.DisabledState.Parent = this.txtDiscription;
            this.txtDiscription.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDiscription.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDiscription.FocusedState.Parent = this.txtDiscription;
            this.txtDiscription.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiscription.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtDiscription.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDiscription.HoverState.Parent = this.txtDiscription;
            this.txtDiscription.Location = new System.Drawing.Point(3, 652);
            this.txtDiscription.Multiline = true;
            this.txtDiscription.Name = "txtDiscription";
            this.txtDiscription.PasswordChar = '\0';
            this.txtDiscription.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtDiscription.PlaceholderText = "Ex: Products Details (Max 50 words)";
            this.txtDiscription.SelectedText = "";
            this.txtDiscription.ShadowDecoration.Parent = this.txtDiscription;
            this.txtDiscription.Size = new System.Drawing.Size(194, 115);
            this.txtDiscription.TabIndex = 146;
            // 
            // txtQuantityPerUnit
            // 
            this.txtQuantityPerUnit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtQuantityPerUnit.DefaultText = "";
            this.txtQuantityPerUnit.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtQuantityPerUnit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtQuantityPerUnit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtQuantityPerUnit.DisabledState.Parent = this.txtQuantityPerUnit;
            this.txtQuantityPerUnit.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtQuantityPerUnit.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtQuantityPerUnit.FocusedState.Parent = this.txtQuantityPerUnit;
            this.txtQuantityPerUnit.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuantityPerUnit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtQuantityPerUnit.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtQuantityPerUnit.HoverState.Parent = this.txtQuantityPerUnit;
            this.txtQuantityPerUnit.Location = new System.Drawing.Point(3, 211);
            this.txtQuantityPerUnit.Name = "txtQuantityPerUnit";
            this.txtQuantityPerUnit.PasswordChar = '\0';
            this.txtQuantityPerUnit.PlaceholderText = "Ex: 10.00";
            this.txtQuantityPerUnit.SelectedText = "";
            this.txtQuantityPerUnit.ShadowDecoration.Parent = this.txtQuantityPerUnit;
            this.txtQuantityPerUnit.Size = new System.Drawing.Size(194, 30);
            this.txtQuantityPerUnit.TabIndex = 58;
            // 
            // txtPerUnitPrice
            // 
            this.txtPerUnitPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPerUnitPrice.DefaultText = "";
            this.txtPerUnitPrice.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtPerUnitPrice.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtPerUnitPrice.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPerUnitPrice.DisabledState.Parent = this.txtPerUnitPrice;
            this.txtPerUnitPrice.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPerUnitPrice.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPerUnitPrice.FocusedState.Parent = this.txtPerUnitPrice;
            this.txtPerUnitPrice.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPerUnitPrice.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtPerUnitPrice.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPerUnitPrice.HoverState.Parent = this.txtPerUnitPrice;
            this.txtPerUnitPrice.Location = new System.Drawing.Point(3, 260);
            this.txtPerUnitPrice.Name = "txtPerUnitPrice";
            this.txtPerUnitPrice.PasswordChar = '\0';
            this.txtPerUnitPrice.PlaceholderText = "Ex: 10.00";
            this.txtPerUnitPrice.SelectedText = "";
            this.txtPerUnitPrice.ShadowDecoration.Parent = this.txtPerUnitPrice;
            this.txtPerUnitPrice.Size = new System.Drawing.Size(194, 30);
            this.txtPerUnitPrice.TabIndex = 59;
            // 
            // txtWeight
            // 
            this.txtWeight.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtWeight.DefaultText = "";
            this.txtWeight.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtWeight.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtWeight.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtWeight.DisabledState.Parent = this.txtWeight;
            this.txtWeight.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtWeight.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtWeight.FocusedState.Parent = this.txtWeight;
            this.txtWeight.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWeight.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtWeight.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtWeight.HoverState.Parent = this.txtWeight;
            this.txtWeight.Location = new System.Drawing.Point(3, 456);
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.PasswordChar = '\0';
            this.txtWeight.PlaceholderText = "Ex: Kg, Mg";
            this.txtWeight.SelectedText = "";
            this.txtWeight.ShadowDecoration.Parent = this.txtWeight;
            this.txtWeight.Size = new System.Drawing.Size(194, 30);
            this.txtWeight.TabIndex = 63;
            // 
            // txtMSRP
            // 
            this.txtMSRP.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMSRP.DefaultText = "";
            this.txtMSRP.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtMSRP.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtMSRP.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtMSRP.DisabledState.Parent = this.txtMSRP;
            this.txtMSRP.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtMSRP.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtMSRP.FocusedState.Parent = this.txtMSRP;
            this.txtMSRP.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMSRP.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtMSRP.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtMSRP.HoverState.Parent = this.txtMSRP;
            this.txtMSRP.Location = new System.Drawing.Point(3, 309);
            this.txtMSRP.Name = "txtMSRP";
            this.txtMSRP.PasswordChar = '\0';
            this.txtMSRP.PlaceholderText = "Ex: 20.00";
            this.txtMSRP.SelectedText = "";
            this.txtMSRP.ShadowDecoration.Parent = this.txtMSRP;
            this.txtMSRP.Size = new System.Drawing.Size(194, 30);
            this.txtMSRP.TabIndex = 60;
            // 
            // txtSize
            // 
            this.txtSize.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSize.DefaultText = "";
            this.txtSize.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtSize.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtSize.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSize.DisabledState.Parent = this.txtSize;
            this.txtSize.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSize.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSize.FocusedState.Parent = this.txtSize;
            this.txtSize.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSize.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtSize.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSize.HoverState.Parent = this.txtSize;
            this.txtSize.Location = new System.Drawing.Point(3, 358);
            this.txtSize.Name = "txtSize";
            this.txtSize.PasswordChar = '\0';
            this.txtSize.PlaceholderText = "Ex: 50";
            this.txtSize.SelectedText = "";
            this.txtSize.ShadowDecoration.Parent = this.txtSize;
            this.txtSize.Size = new System.Drawing.Size(194, 30);
            this.txtSize.TabIndex = 61;
            // 
            // txtColor
            // 
            this.txtColor.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtColor.DefaultText = "";
            this.txtColor.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtColor.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtColor.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtColor.DisabledState.Parent = this.txtColor;
            this.txtColor.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtColor.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtColor.FocusedState.Parent = this.txtColor;
            this.txtColor.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtColor.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtColor.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtColor.HoverState.Parent = this.txtColor;
            this.txtColor.Location = new System.Drawing.Point(3, 407);
            this.txtColor.Name = "txtColor";
            this.txtColor.PasswordChar = '\0';
            this.txtColor.PlaceholderText = "Ex: Red, Blue, Black";
            this.txtColor.SelectedText = "";
            this.txtColor.ShadowDecoration.Parent = this.txtColor;
            this.txtColor.Size = new System.Drawing.Size(194, 30);
            this.txtColor.TabIndex = 62;
            // 
            // txtName
            // 
            this.txtName.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.txtName.BackColor = System.Drawing.Color.Transparent;
            this.txtName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtName.DefaultText = "";
            this.txtName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtName.DisabledState.Parent = this.txtName;
            this.txtName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtName.FocusedState.Parent = this.txtName;
            this.txtName.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtName.HoverState.Parent = this.txtName;
            this.txtName.Location = new System.Drawing.Point(3, 113);
            this.txtName.Name = "txtName";
            this.txtName.PasswordChar = '\0';
            this.txtName.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.txtName.PlaceholderText = "Ex: Chips, Coke, Mobile";
            this.txtName.SelectedText = "";
            this.txtName.ShadowDecoration.Parent = this.txtName;
            this.txtName.Size = new System.Drawing.Size(194, 30);
            this.txtName.TabIndex = 56;
            // 
            // txtStatus
            // 
            this.txtStatus.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtStatus.DefaultText = "";
            this.txtStatus.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtStatus.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtStatus.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtStatus.DisabledState.Parent = this.txtStatus;
            this.txtStatus.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtStatus.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtStatus.FocusedState.Parent = this.txtStatus;
            this.txtStatus.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStatus.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtStatus.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtStatus.HoverState.Parent = this.txtStatus;
            this.txtStatus.Location = new System.Drawing.Point(3, 603);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.PasswordChar = '\0';
            this.txtStatus.PlaceholderText = "Yes or No";
            this.txtStatus.SelectedText = "";
            this.txtStatus.ShadowDecoration.Parent = this.txtStatus;
            this.txtStatus.Size = new System.Drawing.Size(194, 30);
            this.txtStatus.TabIndex = 168;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(60, 900);
            this.label17.Margin = new System.Windows.Forms.Padding(0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(64, 15);
            this.label17.TabIndex = 157;
            this.label17.Text = "Discription";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(84, 844);
            this.label16.Margin = new System.Windows.Forms.Padding(0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(39, 15);
            this.label16.TabIndex = 156;
            this.label16.Text = "Status";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(46, 796);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(80, 15);
            this.label11.TabIndex = 155;
            this.label11.Text = "Discount Rate";
            // 
            // btnRemoveProductPhoto
            // 
            this.btnRemoveProductPhoto.Animated = true;
            this.btnRemoveProductPhoto.CheckedState.Parent = this.btnRemoveProductPhoto;
            this.btnRemoveProductPhoto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRemoveProductPhoto.CustomImages.HoveredImage = global::FinalPoject.Properties.Resources.icons8_remove_image_480px;
            this.btnRemoveProductPhoto.CustomImages.Image = global::FinalPoject.Properties.Resources.icons8_remove_image_480px_1;
            this.btnRemoveProductPhoto.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnRemoveProductPhoto.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnRemoveProductPhoto.CustomImages.Parent = this.btnRemoveProductPhoto;
            this.btnRemoveProductPhoto.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(229)))));
            this.btnRemoveProductPhoto.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveProductPhoto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnRemoveProductPhoto.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnRemoveProductPhoto.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveProductPhoto.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnRemoveProductPhoto.HoverState.Parent = this.btnRemoveProductPhoto;
            this.btnRemoveProductPhoto.Location = new System.Drawing.Point(187, 143);
            this.btnRemoveProductPhoto.Name = "btnRemoveProductPhoto";
            this.btnRemoveProductPhoto.ShadowDecoration.Parent = this.btnRemoveProductPhoto;
            this.btnRemoveProductPhoto.Size = new System.Drawing.Size(190, 37);
            this.btnRemoveProductPhoto.TabIndex = 133;
            this.btnRemoveProductPhoto.Text = "Remove";
            this.btnRemoveProductPhoto.TextOffset = new System.Drawing.Point(12, 0);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(52, 406);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 15);
            this.label4.TabIndex = 153;
            this.label4.Text = "Brand Name";
            // 
            // btnAddProductPhoto
            // 
            this.btnAddProductPhoto.Animated = true;
            this.btnAddProductPhoto.CheckedState.Parent = this.btnAddProductPhoto;
            this.btnAddProductPhoto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddProductPhoto.CustomImages.HoveredImage = global::FinalPoject.Properties.Resources.icons8_edit_image_480px;
            this.btnAddProductPhoto.CustomImages.Image = global::FinalPoject.Properties.Resources.icons8_edit_image_480px_1;
            this.btnAddProductPhoto.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnAddProductPhoto.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnAddProductPhoto.CustomImages.Parent = this.btnAddProductPhoto;
            this.btnAddProductPhoto.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(255)))), ((int)(((byte)(203)))));
            this.btnAddProductPhoto.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProductPhoto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(173)))), ((int)(((byte)(27)))));
            this.btnAddProductPhoto.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(173)))), ((int)(((byte)(27)))));
            this.btnAddProductPhoto.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProductPhoto.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnAddProductPhoto.HoverState.Parent = this.btnAddProductPhoto;
            this.btnAddProductPhoto.Location = new System.Drawing.Point(187, 96);
            this.btnAddProductPhoto.Name = "btnAddProductPhoto";
            this.btnAddProductPhoto.ShadowDecoration.Parent = this.btnAddProductPhoto;
            this.btnAddProductPhoto.Size = new System.Drawing.Size(190, 37);
            this.btnAddProductPhoto.TabIndex = 132;
            this.btnAddProductPhoto.Text = "Add";
            this.btnAddProductPhoto.TextOffset = new System.Drawing.Point(8, 0);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(64, 748);
            this.label15.Margin = new System.Windows.Forms.Padding(0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(61, 15);
            this.label15.TabIndex = 152;
            this.label15.Text = "Unit Stock";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(79, 699);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(45, 15);
            this.label13.TabIndex = 151;
            this.label13.Text = "Weight";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(86, 553);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 15);
            this.label1.TabIndex = 51;
            this.label1.Text = "MSRP";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(88, 649);
            this.label14.Margin = new System.Windows.Forms.Padding(0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(36, 15);
            this.label14.TabIndex = 54;
            this.label14.Text = "Color";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(29, 454);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 15);
            this.label12.TabIndex = 50;
            this.label12.Text = "Quantity Per. Unit";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(58, 259);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 15);
            this.label8.TabIndex = 44;
            this.label8.Text = "Products ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(94, 601);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 15);
            this.label2.TabIndex = 47;
            this.label2.Text = "Size";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(43, 358);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 15);
            this.label7.TabIndex = 45;
            this.label7.Text = "Product Name";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(47, 503);
            this.label10.Margin = new System.Windows.Forms.Padding(0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 15);
            this.label10.TabIndex = 48;
            this.label10.Text = "Per. Unit Price";
            // 
            // pbImage
            // 
            this.pbImage.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pbImage.ErrorImage = global::FinalPoject.Properties.Resources.icons8_no_image_480px_2;
            this.pbImage.Image = global::FinalPoject.Properties.Resources.icons8_add_camera_480px;
            this.pbImage.Location = new System.Drawing.Point(20, 21);
            this.pbImage.Margin = new System.Windows.Forms.Padding(2);
            this.pbImage.Name = "pbImage";
            this.pbImage.ShadowDecoration.Parent = this.pbImage;
            this.pbImage.Size = new System.Drawing.Size(150, 162);
            this.pbImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbImage.TabIndex = 148;
            this.pbImage.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(183, 25);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 20);
            this.label9.TabIndex = 147;
            this.label9.Text = "File Name";
            // 
            // guna2TextBox11
            // 
            this.guna2TextBox11.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox11.DefaultText = "";
            this.guna2TextBox11.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox11.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox11.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox11.DisabledState.Parent = this.guna2TextBox11;
            this.guna2TextBox11.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox11.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox11.FocusedState.Parent = this.guna2TextBox11;
            this.guna2TextBox11.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.guna2TextBox11.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox11.HoverState.Parent = this.guna2TextBox11;
            this.guna2TextBox11.Location = new System.Drawing.Point(187, 50);
            this.guna2TextBox11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.guna2TextBox11.Name = "guna2TextBox11";
            this.guna2TextBox11.PasswordChar = '\0';
            this.guna2TextBox11.PlaceholderText = "filename.jpg/png";
            this.guna2TextBox11.SelectedText = "";
            this.guna2TextBox11.ShadowDecoration.Parent = this.guna2TextBox11;
            this.guna2TextBox11.Size = new System.Drawing.Size(190, 32);
            this.guna2TextBox11.TabIndex = 146;
            // 
            // guna2Panel10
            // 
            this.guna2Panel10.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel10.Location = new System.Drawing.Point(0, 550);
            this.guna2Panel10.Name = "guna2Panel10";
            this.guna2Panel10.ShadowDecoration.Parent = this.guna2Panel10;
            this.guna2Panel10.Size = new System.Drawing.Size(414, 13);
            this.guna2Panel10.TabIndex = 142;
            // 
            // guna2Panel20
            // 
            this.guna2Panel20.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel20.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel20.Location = new System.Drawing.Point(0, 57);
            this.guna2Panel20.Name = "guna2Panel20";
            this.guna2Panel20.ShadowDecoration.Parent = this.guna2Panel20;
            this.guna2Panel20.Size = new System.Drawing.Size(414, 13);
            this.guna2Panel20.TabIndex = 139;
            // 
            // guna2Panel62
            // 
            this.guna2Panel62.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel62.Controls.Add(this.tableLayoutPanel3);
            this.guna2Panel62.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel62.CustomBorderThickness = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.guna2Panel62.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel62.Location = new System.Drawing.Point(0, 563);
            this.guna2Panel62.Name = "guna2Panel62";
            this.guna2Panel62.ShadowDecoration.Parent = this.guna2Panel62;
            this.guna2Panel62.Size = new System.Drawing.Size(414, 57);
            this.guna2Panel62.TabIndex = 132;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.btnCancle, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.btnSaveProduct, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(414, 57);
            this.tableLayoutPanel3.TabIndex = 135;
            // 
            // btnCancle
            // 
            this.btnCancle.Animated = true;
            this.btnCancle.CheckedState.Parent = this.btnCancle;
            this.btnCancle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancle.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnCancle.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnCancle.CustomImages.Parent = this.btnCancle;
            this.btnCancle.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnCancle.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(229)))));
            this.btnCancle.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnCancle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnCancle.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnCancle.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnCancle.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnCancle.HoverState.Parent = this.btnCancle;
            this.btnCancle.Location = new System.Drawing.Point(214, 11);
            this.btnCancle.Name = "btnCancle";
            this.btnCancle.ShadowDecoration.Parent = this.btnCancle;
            this.btnCancle.Size = new System.Drawing.Size(142, 35);
            this.btnCancle.TabIndex = 117;
            this.btnCancle.Text = "Cancel";
            this.btnCancle.Click += new System.EventHandler(this.btnCancle_Click);
            // 
            // btnSaveProduct
            // 
            this.btnSaveProduct.Animated = true;
            this.btnSaveProduct.CheckedState.Parent = this.btnSaveProduct;
            this.btnSaveProduct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveProduct.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSaveProduct.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnSaveProduct.CustomImages.Parent = this.btnSaveProduct;
            this.btnSaveProduct.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSaveProduct.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.btnSaveProduct.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnSaveProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(153)))), ((int)(((byte)(255)))));
            this.btnSaveProduct.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(153)))), ((int)(((byte)(255)))));
            this.btnSaveProduct.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnSaveProduct.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnSaveProduct.HoverState.Parent = this.btnSaveProduct;
            this.btnSaveProduct.Location = new System.Drawing.Point(58, 11);
            this.btnSaveProduct.Name = "btnSaveProduct";
            this.btnSaveProduct.ShadowDecoration.Parent = this.btnSaveProduct;
            this.btnSaveProduct.Size = new System.Drawing.Size(142, 35);
            this.btnSaveProduct.TabIndex = 118;
            this.btnSaveProduct.Text = "Save";
            this.btnSaveProduct.Click += new System.EventHandler(this.btnSaveProduct_Click);
            // 
            // guna2Panel15
            // 
            this.guna2Panel15.Controls.Add(this.guna2Panel16);
            this.guna2Panel15.Controls.Add(this.label5);
            this.guna2Panel15.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel15.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.guna2Panel15.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel15.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel15.Name = "guna2Panel15";
            this.guna2Panel15.ShadowDecoration.Parent = this.guna2Panel15;
            this.guna2Panel15.Size = new System.Drawing.Size(414, 57);
            this.guna2Panel15.TabIndex = 130;
            // 
            // guna2Panel16
            // 
            this.guna2Panel16.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel16.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel16.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel16.Name = "guna2Panel16";
            this.guna2Panel16.ShadowDecoration.Parent = this.guna2Panel16;
            this.guna2Panel16.Size = new System.Drawing.Size(20, 57);
            this.guna2Panel16.TabIndex = 19;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(26, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(163, 21);
            this.label5.TabIndex = 0;
            this.label5.Text = "Enter Product Details";
            // 
            // guna2Panel11
            // 
            this.guna2Panel11.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel11.BorderColor = System.Drawing.Color.Silver;
            this.guna2Panel11.BorderRadius = 12;
            this.guna2Panel11.BorderThickness = 1;
            this.guna2Panel11.Controls.Add(this.dgvAllProduct);
            this.guna2Panel11.Controls.Add(this.guna2Panel22);
            this.guna2Panel11.Controls.Add(this.guna2Panel21);
            this.guna2Panel11.Controls.Add(this.guna2Panel19);
            this.guna2Panel11.Controls.Add(this.guna2Panel18);
            this.guna2Panel11.Controls.Add(this.guna2Panel13);
            this.guna2Panel11.Controls.Add(this.guna2Panel7);
            this.guna2Panel11.Controls.Add(this.guna2Panel2);
            this.guna2Panel11.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2Panel11.FillColor = System.Drawing.Color.White;
            this.guna2Panel11.Location = new System.Drawing.Point(3, 3);
            this.guna2Panel11.Name = "guna2Panel11";
            this.guna2Panel11.ShadowDecoration.Parent = this.guna2Panel11;
            this.guna2Panel11.Size = new System.Drawing.Size(773, 620);
            this.guna2Panel11.TabIndex = 27;
            // 
            // dgvAllProduct
            // 
            this.dgvAllProduct.AllowUserToAddRows = false;
            this.dgvAllProduct.AllowUserToDeleteRows = false;
            this.dgvAllProduct.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvAllProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAllProduct.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.pID,
            this.pTag,
            this.pName,
            this.pBrandName,
            this.pStatus,
            this.pMSRP,
            this.pPerUnPrice,
            this.pQuaPerUn,
            this.pDisRate,
            this.pUnStock,
            this.pSize,
            this.pColor,
            this.pWeight,
            this.pDisc});
            this.dgvAllProduct.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAllProduct.Location = new System.Drawing.Point(8, 128);
            this.dgvAllProduct.Margin = new System.Windows.Forms.Padding(2);
            this.dgvAllProduct.Name = "dgvAllProduct";
            this.dgvAllProduct.ReadOnly = true;
            this.dgvAllProduct.RowHeadersWidth = 51;
            this.dgvAllProduct.RowTemplate.Height = 24;
            this.dgvAllProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAllProduct.Size = new System.Drawing.Size(757, 427);
            this.dgvAllProduct.TabIndex = 151;
            this.dgvAllProduct.DoubleClick += new System.EventHandler(this.dgvAllProduct_DoubleClick);
            // 
            // pID
            // 
            this.pID.DataPropertyName = "ProductId";
            this.pID.HeaderText = "ID";
            this.pID.MinimumWidth = 6;
            this.pID.Name = "pID";
            this.pID.ReadOnly = true;
            this.pID.Width = 125;
            // 
            // pTag
            // 
            this.pTag.DataPropertyName = "ProductIdTag";
            this.pTag.HeaderText = "Tag";
            this.pTag.MinimumWidth = 6;
            this.pTag.Name = "pTag";
            this.pTag.ReadOnly = true;
            this.pTag.Width = 125;
            // 
            // pName
            // 
            this.pName.DataPropertyName = "ProductName";
            this.pName.HeaderText = "Name";
            this.pName.MinimumWidth = 6;
            this.pName.Name = "pName";
            this.pName.ReadOnly = true;
            this.pName.Width = 125;
            // 
            // pBrandName
            // 
            this.pBrandName.DataPropertyName = "BrandName";
            this.pBrandName.HeaderText = "Brand Name";
            this.pBrandName.MinimumWidth = 6;
            this.pBrandName.Name = "pBrandName";
            this.pBrandName.ReadOnly = true;
            this.pBrandName.Width = 125;
            // 
            // pStatus
            // 
            this.pStatus.DataPropertyName = "ProductStatus";
            this.pStatus.HeaderText = "Status";
            this.pStatus.MinimumWidth = 6;
            this.pStatus.Name = "pStatus";
            this.pStatus.ReadOnly = true;
            this.pStatus.Width = 125;
            // 
            // pMSRP
            // 
            this.pMSRP.DataPropertyName = "ProductMSRP";
            this.pMSRP.HeaderText = "MSRP";
            this.pMSRP.MinimumWidth = 6;
            this.pMSRP.Name = "pMSRP";
            this.pMSRP.ReadOnly = true;
            this.pMSRP.Width = 125;
            // 
            // pPerUnPrice
            // 
            this.pPerUnPrice.DataPropertyName = "ProductPerUnitPrice";
            this.pPerUnPrice.HeaderText = "Per Unit Price";
            this.pPerUnPrice.MinimumWidth = 6;
            this.pPerUnPrice.Name = "pPerUnPrice";
            this.pPerUnPrice.ReadOnly = true;
            this.pPerUnPrice.Width = 125;
            // 
            // pQuaPerUn
            // 
            this.pQuaPerUn.DataPropertyName = "ProductQuantityPerUnit";
            this.pQuaPerUn.HeaderText = "Quantity Per Unit";
            this.pQuaPerUn.MinimumWidth = 6;
            this.pQuaPerUn.Name = "pQuaPerUn";
            this.pQuaPerUn.ReadOnly = true;
            this.pQuaPerUn.Width = 125;
            // 
            // pDisRate
            // 
            this.pDisRate.DataPropertyName = "ProductDiscountRate";
            this.pDisRate.HeaderText = "Discount Rate";
            this.pDisRate.MinimumWidth = 6;
            this.pDisRate.Name = "pDisRate";
            this.pDisRate.ReadOnly = true;
            this.pDisRate.Width = 125;
            // 
            // pUnStock
            // 
            this.pUnStock.DataPropertyName = "ProductUnitStock";
            this.pUnStock.HeaderText = "Unit Stock";
            this.pUnStock.MinimumWidth = 6;
            this.pUnStock.Name = "pUnStock";
            this.pUnStock.ReadOnly = true;
            this.pUnStock.Width = 125;
            // 
            // pSize
            // 
            this.pSize.DataPropertyName = "ProductSize";
            this.pSize.HeaderText = "Size";
            this.pSize.MinimumWidth = 6;
            this.pSize.Name = "pSize";
            this.pSize.ReadOnly = true;
            this.pSize.Width = 125;
            // 
            // pColor
            // 
            this.pColor.DataPropertyName = "ProductColor";
            this.pColor.HeaderText = "Color";
            this.pColor.MinimumWidth = 6;
            this.pColor.Name = "pColor";
            this.pColor.ReadOnly = true;
            this.pColor.Width = 125;
            // 
            // pWeight
            // 
            this.pWeight.DataPropertyName = "ProductWeight";
            this.pWeight.HeaderText = "Weight";
            this.pWeight.MinimumWidth = 6;
            this.pWeight.Name = "pWeight";
            this.pWeight.ReadOnly = true;
            this.pWeight.Width = 125;
            // 
            // pDisc
            // 
            this.pDisc.DataPropertyName = "ProductDescription";
            this.pDisc.HeaderText = "Description";
            this.pDisc.MinimumWidth = 6;
            this.pDisc.Name = "pDisc";
            this.pDisc.ReadOnly = true;
            this.pDisc.Width = 125;
            // 
            // guna2Panel22
            // 
            this.guna2Panel22.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel22.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel22.Location = new System.Drawing.Point(8, 555);
            this.guna2Panel22.Name = "guna2Panel22";
            this.guna2Panel22.ShadowDecoration.Parent = this.guna2Panel22;
            this.guna2Panel22.Size = new System.Drawing.Size(757, 8);
            this.guna2Panel22.TabIndex = 150;
            // 
            // guna2Panel21
            // 
            this.guna2Panel21.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel21.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel21.Location = new System.Drawing.Point(8, 120);
            this.guna2Panel21.Name = "guna2Panel21";
            this.guna2Panel21.ShadowDecoration.Parent = this.guna2Panel21;
            this.guna2Panel21.Size = new System.Drawing.Size(757, 8);
            this.guna2Panel21.TabIndex = 149;
            // 
            // guna2Panel19
            // 
            this.guna2Panel19.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel19.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel19.Location = new System.Drawing.Point(765, 120);
            this.guna2Panel19.Name = "guna2Panel19";
            this.guna2Panel19.ShadowDecoration.Parent = this.guna2Panel19;
            this.guna2Panel19.Size = new System.Drawing.Size(8, 443);
            this.guna2Panel19.TabIndex = 147;
            // 
            // guna2Panel18
            // 
            this.guna2Panel18.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel18.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel18.Location = new System.Drawing.Point(0, 120);
            this.guna2Panel18.Name = "guna2Panel18";
            this.guna2Panel18.ShadowDecoration.Parent = this.guna2Panel18;
            this.guna2Panel18.Size = new System.Drawing.Size(8, 443);
            this.guna2Panel18.TabIndex = 146;
            // 
            // guna2Panel13
            // 
            this.guna2Panel13.Controls.Add(this.tableLayoutPanel4);
            this.guna2Panel13.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel13.CustomBorderThickness = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.guna2Panel13.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel13.Location = new System.Drawing.Point(0, 563);
            this.guna2Panel13.Name = "guna2Panel13";
            this.guna2Panel13.ShadowDecoration.Parent = this.guna2Panel13;
            this.guna2Panel13.Size = new System.Drawing.Size(773, 57);
            this.guna2Panel13.TabIndex = 133;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 5;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 225F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 225F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.btnRefresh, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.btnDeleteProduct, 3, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 3;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(773, 57);
            this.tableLayoutPanel4.TabIndex = 137;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Animated = true;
            this.btnRefresh.CheckedState.Parent = this.btnRefresh;
            this.btnRefresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefresh.CustomImages.HoveredImage = global::FinalPoject.Properties.Resources.icons8_edit_image_480px;
            this.btnRefresh.CustomImages.Image = global::FinalPoject.Properties.Resources.icons8_edit_image_480px_1;
            this.btnRefresh.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnRefresh.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnRefresh.CustomImages.Parent = this.btnRefresh;
            this.btnRefresh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRefresh.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(255)))), ((int)(((byte)(203)))));
            this.btnRefresh.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(173)))), ((int)(((byte)(27)))));
            this.btnRefresh.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(173)))), ((int)(((byte)(27)))));
            this.btnRefresh.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnRefresh.HoverState.Parent = this.btnRefresh;
            this.btnRefresh.Location = new System.Drawing.Point(160, 11);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.ShadowDecoration.Parent = this.btnRefresh;
            this.btnRefresh.Size = new System.Drawing.Size(219, 35);
            this.btnRefresh.TabIndex = 133;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.TextOffset = new System.Drawing.Point(8, 0);
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnDeleteProduct
            // 
            this.btnDeleteProduct.Animated = true;
            this.btnDeleteProduct.CheckedState.Parent = this.btnDeleteProduct;
            this.btnDeleteProduct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeleteProduct.CustomImages.HoveredImage = global::FinalPoject.Properties.Resources.icons8_trash_can_480px;
            this.btnDeleteProduct.CustomImages.Image = global::FinalPoject.Properties.Resources.icons8_trash_can_480px_1;
            this.btnDeleteProduct.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnDeleteProduct.CustomImages.ImageOffset = new System.Drawing.Point(10, -1);
            this.btnDeleteProduct.CustomImages.Parent = this.btnDeleteProduct;
            this.btnDeleteProduct.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDeleteProduct.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(226)))), ((int)(((byte)(229)))));
            this.btnDeleteProduct.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnDeleteProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnDeleteProduct.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.btnDeleteProduct.HoverState.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold);
            this.btnDeleteProduct.HoverState.ForeColor = System.Drawing.Color.White;
            this.btnDeleteProduct.HoverState.Parent = this.btnDeleteProduct;
            this.btnDeleteProduct.Location = new System.Drawing.Point(393, 11);
            this.btnDeleteProduct.Name = "btnDeleteProduct";
            this.btnDeleteProduct.ShadowDecoration.Parent = this.btnDeleteProduct;
            this.btnDeleteProduct.Size = new System.Drawing.Size(219, 35);
            this.btnDeleteProduct.TabIndex = 135;
            this.btnDeleteProduct.Text = "Delete Product";
            this.btnDeleteProduct.Click += new System.EventHandler(this.btnDeleteProduct_Click);
            // 
            // guna2Panel7
            // 
            this.guna2Panel7.Controls.Add(this.guna2Panel8);
            this.guna2Panel7.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel7.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.guna2Panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel7.Location = new System.Drawing.Point(0, 57);
            this.guna2Panel7.Name = "guna2Panel7";
            this.guna2Panel7.ShadowDecoration.Parent = this.guna2Panel7;
            this.guna2Panel7.Size = new System.Drawing.Size(773, 63);
            this.guna2Panel7.TabIndex = 132;
            // 
            // guna2Panel8
            // 
            this.guna2Panel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel8.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel8.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel8.Name = "guna2Panel8";
            this.guna2Panel8.ShadowDecoration.Parent = this.guna2Panel8;
            this.guna2Panel8.Size = new System.Drawing.Size(20, 63);
            this.guna2Panel8.TabIndex = 19;
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.guna2Panel14);
            this.guna2Panel2.Controls.Add(this.guna2Panel5);
            this.guna2Panel2.Controls.Add(this.label6);
            this.guna2Panel2.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Panel2.CustomBorderThickness = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.guna2Panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel2.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.ShadowDecoration.Parent = this.guna2Panel2;
            this.guna2Panel2.Size = new System.Drawing.Size(773, 57);
            this.guna2Panel2.TabIndex = 131;
            // 
            // guna2Panel14
            // 
            this.guna2Panel14.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel14.Controls.Add(this.label24);
            this.guna2Panel14.Controls.Add(this.guna2Panel17);
            this.guna2Panel14.Controls.Add(this.txtSearchProduct);
            this.guna2Panel14.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel14.Location = new System.Drawing.Point(384, 0);
            this.guna2Panel14.Name = "guna2Panel14";
            this.guna2Panel14.ShadowDecoration.Parent = this.guna2Panel14;
            this.guna2Panel14.Size = new System.Drawing.Size(389, 57);
            this.guna2Panel14.TabIndex = 21;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.label24.Location = new System.Drawing.Point(10, 19);
            this.label24.Margin = new System.Windows.Forms.Padding(0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(101, 19);
            this.label24.TabIndex = 164;
            this.label24.Text = "Search Product";
            // 
            // guna2Panel17
            // 
            this.guna2Panel17.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel17.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel17.Location = new System.Drawing.Point(369, 0);
            this.guna2Panel17.Name = "guna2Panel17";
            this.guna2Panel17.ShadowDecoration.Parent = this.guna2Panel17;
            this.guna2Panel17.Size = new System.Drawing.Size(20, 57);
            this.guna2Panel17.TabIndex = 135;
            // 
            // txtSearchProduct
            // 
            this.txtSearchProduct.AccessibleRole = System.Windows.Forms.AccessibleRole.Grip;
            this.txtSearchProduct.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSearchProduct.DefaultText = "";
            this.txtSearchProduct.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtSearchProduct.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtSearchProduct.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSearchProduct.DisabledState.Parent = this.txtSearchProduct;
            this.txtSearchProduct.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSearchProduct.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSearchProduct.FocusedState.Parent = this.txtSearchProduct;
            this.txtSearchProduct.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchProduct.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSearchProduct.HoverState.Parent = this.txtSearchProduct;
            this.txtSearchProduct.HoverState.PlaceholderForeColor = System.Drawing.Color.Transparent;
            this.txtSearchProduct.IconRight = global::FinalPoject.Properties.Resources.icons8_search_480px;
            this.txtSearchProduct.Location = new System.Drawing.Point(116, 13);
            this.txtSearchProduct.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtSearchProduct.Name = "txtSearchProduct";
            this.txtSearchProduct.PasswordChar = '\0';
            this.txtSearchProduct.PlaceholderText = "by Name, Tag, Cate. Brand";
            this.txtSearchProduct.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtSearchProduct.SelectedText = "";
            this.txtSearchProduct.ShadowDecoration.Parent = this.txtSearchProduct;
            this.txtSearchProduct.Size = new System.Drawing.Size(245, 30);
            this.txtSearchProduct.TabIndex = 134;
            this.txtSearchProduct.TextChanged += new System.EventHandler(this.txtSearchProduct_TextChanged);
            // 
            // guna2Panel5
            // 
            this.guna2Panel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel5.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel5.Name = "guna2Panel5";
            this.guna2Panel5.ShadowDecoration.Parent = this.guna2Panel5;
            this.guna2Panel5.Size = new System.Drawing.Size(20, 57);
            this.guna2Panel5.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(26, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(130, 21);
            this.label6.TabIndex = 0;
            this.label6.Text = "View All Product";
            // 
            // pnlOrderSelect
            // 
            this.pnlOrderSelect.BackColor = System.Drawing.Color.Transparent;
            this.pnlOrderSelect.BorderColor = System.Drawing.Color.Silver;
            this.pnlOrderSelect.BorderRadius = 12;
            this.pnlOrderSelect.BorderThickness = 1;
            this.pnlOrderSelect.Controls.Add(this.guna2Panel6);
            this.pnlOrderSelect.CustomBorderColor = System.Drawing.Color.Silver;
            this.pnlOrderSelect.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlOrderSelect.FillColor = System.Drawing.Color.White;
            this.pnlOrderSelect.Location = new System.Drawing.Point(15, 16);
            this.pnlOrderSelect.Name = "pnlOrderSelect";
            this.pnlOrderSelect.ShadowDecoration.Parent = this.pnlOrderSelect;
            this.pnlOrderSelect.Size = new System.Drawing.Size(1214, 73);
            this.pnlOrderSelect.TabIndex = 21;
            // 
            // guna2Panel6
            // 
            this.guna2Panel6.Controls.Add(this.label25);
            this.guna2Panel6.Controls.Add(this.label3);
            this.guna2Panel6.Controls.Add(this.guna2Panel9);
            this.guna2Panel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel6.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel6.Name = "guna2Panel6";
            this.guna2Panel6.ShadowDecoration.Parent = this.guna2Panel6;
            this.guna2Panel6.Size = new System.Drawing.Size(358, 73);
            this.guna2Panel6.TabIndex = 5;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.label25.Location = new System.Drawing.Point(134, 21);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(153, 30);
            this.label25.TabIndex = 20;
            this.label25.Text = "Manager View";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(26, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 30);
            this.label3.TabIndex = 2;
            this.label3.Text = "Product :";
            // 
            // guna2Panel9
            // 
            this.guna2Panel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel9.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel9.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel9.Name = "guna2Panel9";
            this.guna2Panel9.ShadowDecoration.Parent = this.guna2Panel9;
            this.guna2Panel9.Size = new System.Drawing.Size(22, 73);
            this.guna2Panel9.TabIndex = 19;
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = null;
            // 
            // guna2ElipseAddProducts
            // 
            this.guna2ElipseAddProducts.BorderRadius = 12;
            // 
            // FormAddProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1244, 747);
            this.Controls.Add(this.guna2Panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1088, 786);
            this.Name = "FormAddProduct";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.FormAddProduct_Load);
            this.guna2Panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.guna2Panel12.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).EndInit();
            this.guna2Panel62.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.guna2Panel15.ResumeLayout(false);
            this.guna2Panel15.PerformLayout();
            this.guna2Panel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAllProduct)).EndInit();
            this.guna2Panel13.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.guna2Panel7.ResumeLayout(false);
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel2.PerformLayout();
            this.guna2Panel14.ResumeLayout(false);
            this.guna2Panel14.PerformLayout();
            this.pnlOrderSelect.ResumeLayout(false);
            this.guna2Panel6.ResumeLayout(false);
            this.guna2Panel6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel pnlInsideTop;
        private Guna.UI2.WinForms.Guna2Panel pnlBottom;
        private Guna.UI2.WinForms.Guna2Panel pnlInsideLeft;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel4;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Guna.UI2.WinForms.Guna2Elipse guna2ElipseAddProducts;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel12;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel10;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel20;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel62;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel15;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel16;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2Panel pnlOrderSelect;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel6;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel9;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2PictureBox pbImage;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel11;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private Guna.UI2.WinForms.Guna2Button btnCancle;
        private Guna.UI2.WinForms.Guna2Button btnSaveProduct;
        private Guna.UI2.WinForms.Guna2Button btnAddProductPhoto;
        private Guna.UI2.WinForms.Guna2Button btnRemoveProductPhoto;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel13;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel7;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel14;
        private Guna.UI2.WinForms.Guna2TextBox txtSearchProduct;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel17;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductId;
        private Guna.UI2.WinForms.Guna2Button btnRefresh;
        private Guna.UI2.WinForms.Guna2Button btnDeleteProduct;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel19;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel18;
        private System.Windows.Forms.DataGridView dgvAllProduct;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel22;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel21;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private Guna.UI2.WinForms.Guna2TextBox txtTag;
        private Guna.UI2.WinForms.Guna2TextBox txtId;
        private Guna.UI2.WinForms.Guna2TextBox txtUniStock;
        private Guna.UI2.WinForms.Guna2ComboBox cmbBrand;
        private Guna.UI2.WinForms.Guna2TextBox txtDiscription;
        private Guna.UI2.WinForms.Guna2TextBox txtQuantityPerUnit;
        private Guna.UI2.WinForms.Guna2TextBox txtWeight;
        private Guna.UI2.WinForms.Guna2TextBox txtDiscountRate;
        private Guna.UI2.WinForms.Guna2TextBox txtMSRP;
        private Guna.UI2.WinForms.Guna2TextBox txtSize;
        private Guna.UI2.WinForms.Guna2TextBox txtColor;
        private Guna.UI2.WinForms.Guna2TextBox txtName;
        private Guna.UI2.WinForms.Guna2TextBox txtStatus;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2TextBox txtPerUnitPrice;
        private Guna.UI2.WinForms.Guna2Button btnAddBarnd;
        private System.Windows.Forms.DataGridViewTextBoxColumn pID;
        private System.Windows.Forms.DataGridViewTextBoxColumn pTag;
        private System.Windows.Forms.DataGridViewTextBoxColumn pName;
        private System.Windows.Forms.DataGridViewTextBoxColumn pBrandName;
        private System.Windows.Forms.DataGridViewTextBoxColumn pStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn pMSRP;
        private System.Windows.Forms.DataGridViewTextBoxColumn pPerUnPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn pQuaPerUn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pDisRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn pUnStock;
        private System.Windows.Forms.DataGridViewTextBoxColumn pSize;
        private System.Windows.Forms.DataGridViewTextBoxColumn pColor;
        private System.Windows.Forms.DataGridViewTextBoxColumn pWeight;
        private System.Windows.Forms.DataGridViewTextBoxColumn pDisc;
    }
}